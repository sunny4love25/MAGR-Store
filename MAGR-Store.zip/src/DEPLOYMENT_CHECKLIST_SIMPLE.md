# ✅ MAGR Store Deployment Checklist

Quick checklist to deploy your store in under 30 minutes!

---

## 📋 Pre-Deployment

- [ ] **Code is ready**
  - [ ] All files present
  - [ ] No syntax errors
  - [ ] `npm install` completes successfully
  - [ ] `npm run build` succeeds

- [ ] **Accounts created**
  - [ ] GitHub account
  - [ ] Vercel account  
  - [ ] Supabase account

---

## 🔐 Step 1: Environment Setup (5 minutes)

### Generate Encryption Key:

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
```

**Copy the output** - you'll need it!

### Required Environment Variables:

```env
VITE_SUPABASE_URL=https://xxxxx.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGc...
VITE_ENCRYPTION_KEY=<your-generated-key>
```

**Save these somewhere safe!**

---

## 🗄️ Step 2: Supabase Setup (10 minutes)

- [ ] **Create Supabase project**
  1. Go to [supabase.com](https://supabase.com)
  2. Click "New Project"
  3. Choose name and password
  4. Wait for project creation

- [ ] **Run database setup**
  1. Go to SQL Editor
  2. Open `supabase-setup.sql` file
  3. Copy all contents
  4. Paste and click "Run"
  5. Verify no errors

- [ ] **Get credentials**
  1. Go to Settings → API
  2. Copy Project URL
  3. Copy Anon public key
  4. Save both values

---

## 📦 Step 3: Push to GitHub (5 minutes)

```bash
# Create new repository on GitHub first
# Then run these commands:

git init
git add .
git commit -m "Initial commit - MAGR Store"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPO.git
git push -u origin main
```

**Verify** your code is on GitHub!

---

## 🚀 Step 4: Deploy to Vercel (10 minutes)

- [ ] **Import project**
  1. Go to [vercel.com](https://vercel.com)
  2. Click "Add New" → "Project"
  3. Import from GitHub
  4. Select your repository

- [ ] **Add environment variables**
  
  In Vercel settings, add:
  
  | Variable | Value |
  |----------|-------|
  | `VITE_SUPABASE_URL` | From Supabase Settings → API |
  | `VITE_SUPABASE_ANON_KEY` | From Supabase Settings → API |
  | `VITE_ENCRYPTION_KEY` | Generated in Step 1 |

- [ ] **Deploy**
  1. Click "Deploy"
  2. Wait 1-3 minutes
  3. Get your live URL

---

## ✅ Step 5: Verify Deployment (5 minutes)

Visit your live site and check:

- [ ] **Site loads** without errors
- [ ] **Products display** correctly
- [ ] **Images load**
- [ ] **Cart works**
- [ ] **Search works**
- [ ] **No console errors** (Press F12)

**If everything works → You're DONE! 🎉**

---

## 🔧 Step 6: Optional - Configure SMTP

Only if you want email functionality:

- [ ] **Get Gmail app password**
  1. Enable 2FA on Google account
  2. Generate app password: [myaccount.google.com/apppasswords](https://myaccount.google.com/apppasswords)

- [ ] **Configure in Admin Panel**
  1. Visit your site
  2. Click Admin icon (top right)
  3. Go to "Email Settings"
  4. Enter SMTP details:
     - Host: `smtp.gmail.com`
     - Port: `587`
     - Username: Your Gmail
     - Password: App password
  5. Save and test

---

## 🎯 Success Indicators

You know deployment succeeded when:

✅ **Live URL works**: `https://your-app.vercel.app`  
✅ **No build errors** in Vercel logs  
✅ **Products load** from database  
✅ **Console is clean** (no red errors)  
✅ **Features work** (cart, search, wishlist)  

---

## 🐛 Common Issues & Quick Fixes

### Issue: "Failed to fetch"
**Fix**: Check Supabase environment variables in Vercel

### Issue: Build fails
**Fix**: Verify all 3 environment variables are set exactly:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`  
- `VITE_ENCRYPTION_KEY`

### Issue: Products don't show
**Fix**: Verify `supabase-setup.sql` was run completely

### Issue: Images broken
**Fix**: Check browser console for actual errors

---

## 📞 Need Help?

1. **Check deployment logs** in Vercel
2. **Check browser console** (F12)
3. **Read detailed guide**: `GITHUB_DEPLOYMENT_GUIDE.md`
4. **Check troubleshooting**: `TROUBLESHOOTING.md`

---

## 🎊 After Deployment

### Immediate:
- [ ] Share your site URL
- [ ] Test all features
- [ ] Configure branding

### This Week:
- [ ] Add real products
- [ ] Set up payment processing
- [ ] Configure domain (optional)

### Later:
- [ ] Enable Temu features (see `ENABLE_TEMU_FEATURES.md`)
- [ ] Monitor analytics
- [ ] Optimize SEO

---

## ⏱️ Total Time: ~30 Minutes

- Environment setup: 5 min
- Supabase: 10 min
- GitHub: 5 min
- Vercel: 10 min
- Verification: 5 min

**Your store will be live in less time than ordering pizza! 🍕**

---

## 🎯 Quick Commands Reference

```bash
# Generate encryption key
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"

# Build locally
npm run build

# Push to GitHub
git add .
git commit -m "Update"
git push origin main

# Vercel auto-deploys from GitHub!
```

---

**You've got this! 🚀**

*Follow the steps in order and you'll be live in 30 minutes!*

---

*Last Updated: October 26, 2025*
