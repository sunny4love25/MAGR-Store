# 🚨 Common Deployment Errors & Quick Fixes

Quick reference for the most common deployment issues and their solutions.

---

## 🔴 Vercel: "No Output Directory named 'dist' found"

### The Error:
```
Error: No Output Directory named "dist" found after the Build completed.
```

### The Fix:
**👉 IMPORTANT: See [VERCEL_FIX_STEP_BY_STEP.md](VERCEL_FIX_STEP_BY_STEP.md) for complete solution!**

**Quick Steps:**
1. **Go to Vercel Dashboard** → Your Project → **Settings**
2. Navigate to **Build & Development Settings**
3. Set these values:
   ```
   Framework Preset:     Vite
   Build Command:        vite build
   Output Directory:     dist
   Install Command:      npm install
   Development Command:  vite
   ```
4. **Clear Build Cache** (in same settings page)
5. **Save** and click **Redeploy** (without cache)

### Why It Happens:
Your build outputs to `build/` but Vercel expects `dist/`. Dashboard settings override vercel.json.

### Detailed Guides:
- **Step-by-step fix:** [VERCEL_FIX_STEP_BY_STEP.md](VERCEL_FIX_STEP_BY_STEP.md) ⭐
- **Alternative solutions:** [VERCEL_DEPLOYMENT_FIX.md](VERCEL_DEPLOYMENT_FIX.md)

---

## 🔴 Netlify: Build Failed

### Common Causes:

**1. Missing Environment Variables**
- Go to **Site settings** → **Build & deploy** → **Environment**
- Add:
  - `VITE_SUPABASE_URL`
  - `VITE_SUPABASE_ANON_KEY`

**2. Node Version**
- Add `.nvmrc` file with: `18`
- Or set in Netlify UI: **Site settings** → **Build & deploy** → **Environment**
- Set `NODE_VERSION` to `18`

**3. Build Command**
```
Build command: npm run build
Publish directory: dist
```

---

## 🔴 Build Error: "Cannot find module"

### Error Examples:
```
Error: Cannot find module 'react'
Error: Cannot find module '@supabase/supabase-js'
```

### The Fix:
```bash
# Delete node_modules and package-lock.json
rm -rf node_modules package-lock.json

# Reinstall dependencies
npm install

# Try building again
npm run build
```

### Windows Users:
```cmd
rmdir /s /q node_modules
del package-lock.json
npm install
npm run build
```

---

## 🔴 TypeScript Errors During Build

### Error:
```
error TS2307: Cannot find module 'X' or its corresponding type declarations.
```

### The Fix:
```bash
# Install missing type definitions
npm install --save-dev @types/react @types/react-dom

# Or reinstall all dependencies
npm install
```

### Check tsconfig.json:
Make sure `tsconfig.json` exists in your project root.

---

## 🔴 Environment Variables Not Working

### Symptoms:
- Database connection fails
- Features don't work in production
- `undefined` errors in console

### The Fix:

**For Vercel:**
1. Dashboard → Settings → Environment Variables
2. Add variables (must start with `VITE_`)
3. Redeploy

**For Netlify:**
1. Site settings → Build & deploy → Environment
2. Add variables
3. Trigger deploy

**For Local:**
1. Create `.env.local` (copy from `.env.example`)
2. Add your values
3. Restart dev server

### Important:
- ✅ Variables MUST start with `VITE_`
- ✅ Rebuild after adding variables
- ✅ Never commit `.env.local` to Git

---

## 🔴 Database Connection Failed

### Error:
```
Failed to connect to Supabase
Invalid API key
```

### The Fix:

1. **Check Supabase credentials:**
   - Go to Supabase Dashboard → Settings → API
   - Copy fresh URL and anon key
   - Update `.env.local` or hosting environment variables

2. **Verify format:**
   ```env
   VITE_SUPABASE_URL=https://xxxxx.supabase.co
   VITE_SUPABASE_ANON_KEY=eyJxxxx...
   ```

3. **Check Supabase project:**
   - Is project paused? (Free tier pauses after inactivity)
   - Restore if needed

---

## 🔴 Large Bundle Size Warning

### Warning:
```
(!) Some chunks are larger than 500 kB after minification.
```

### The Fix:
This is just a **warning**, not an error. Your app will still work.

**To optimize (optional):**
1. Code is already split in `vite.config.ts`
2. Images are lazy-loaded
3. Components use React.memo

**To suppress warning:**
Edit `vite.config.ts`:
```typescript
build: {
  chunkSizeWarningLimit: 1000, // Increase limit
}
```

---

## 🔴 Page Not Found (404) After Deployment

### Symptoms:
- Home page works
- Other routes show 404

### The Fix:

**Netlify:**
Already configured in `netlify.toml` ✅

**Vercel:**
Already configured in `vercel.json` ✅

**GitHub Pages:**
Add `404.html` that redirects to `index.html`

**Other Hosts:**
Configure server to redirect all routes to `index.html`

---

## 🔴 SMTP Email Not Sending

### Symptoms:
- Test email fails
- Campaign emails not delivered

### The Fix:

1. **Verify SMTP credentials** in Admin Panel
2. **Test connection** using "Test Email" button
3. **Check provider:**
   - Gmail: Use App Password, not regular password
   - SendGrid: Verify sender email
   - Mailgun: Check API key

4. **Common Issues:**
   - Port 587 (not 25 or 465)
   - Enable "Less Secure Apps" (Gmail)
   - Sender email verified with provider

---

## 🔴 Images Not Loading

### Symptoms:
- Broken image icons
- Images show alt text only

### The Fix:

1. **Check image URLs** - Must be valid and accessible
2. **Use Unsplash** for placeholder images
3. **Check CORS** - Image hosts must allow cross-origin requests
4. **Use ImageWithFallback component** (already included)

---

## 🔴 "Failed to load module script"

### Error in Browser Console:
```
Failed to load module script: Expected a JavaScript module script...
```

### The Fix:

**For Vite:**
1. Clear browser cache (Ctrl+Shift+Delete)
2. Hard refresh (Ctrl+Shift+R)
3. Check `vite.config.ts` is correct

**For Production:**
1. Clear deployment cache
2. Rebuild: `npm run build`
3. Redeploy

---

## 🔴 Port Already in Use

### Error:
```
Port 5173 is already in use
```

### The Fix:

**Kill the process:**

**Mac/Linux:**
```bash
lsof -ti:5173 | xargs kill -9
```

**Windows PowerShell:**
```powershell
Get-Process -Id (Get-NetTCPConnection -LocalPort 5173).OwningProcess | Stop-Process
```

**Or change port:**
Edit `vite.config.ts`:
```typescript
server: {
  port: 5174, // Use different port
}
```

---

## 🔴 Deployment Succeeds But Site Shows Blank Page

### Symptoms:
- Build succeeds
- Site loads but shows blank white screen
- No errors in deployment logs

### The Fix:

1. **Check Browser Console** (F12)
   - Look for JavaScript errors
   - Check for missing environment variables

2. **Verify Environment Variables:**
   - All `VITE_*` variables set in hosting dashboard
   - Values are correct (no typos)

3. **Check Build Output:**
   - Files exist in deployment
   - index.html is at root

4. **Test Locally:**
   ```bash
   npm run build
   npm run preview
   ```
   - If it works locally, issue is with hosting config

---

## 🔴 CSS Not Loading / Styling Broken

### Symptoms:
- Site loads but has no styling
- Everything is black text on white

### The Fix:

1. **Check Tailwind CSS import** in `main.tsx`:
   ```typescript
   import './styles/globals.css';
   ```

2. **Verify globals.css exists** at `styles/globals.css`

3. **Rebuild:**
   ```bash
   npm run build
   ```

4. **Clear browser cache**

---

## 🔴 "Supabase client not initialized"

### Error:
```
Cannot read properties of null (reading 'from')
Supabase client not initialized
```

### The Fix:

1. **Check environment variables are set**
2. **Verify Supabase URL format:**
   ```
   https://xxxxx.supabase.co
   NOT: https://app.supabase.com/project/xxxxx
   ```

3. **Restart dev server** after adding variables

---

## ✅ Quick Diagnostic Checklist

When deployment fails, check:

- [ ] Node.js v16+ installed
- [ ] All dependencies installed (`npm install`)
- [ ] Build succeeds locally (`npm run build`)
- [ ] Environment variables set correctly
- [ ] Environment variables start with `VITE_`
- [ ] Supabase project is active
- [ ] Database tables created (ran SQL script)
- [ ] Framework preset set correctly (Vite)
- [ ] Build command: `npm run build`
- [ ] Output directory: `dist`
- [ ] No TypeScript errors
- [ ] Browser cache cleared

---

## 🆘 Still Stuck?

### Try These in Order:

1. **Clear everything and start fresh:**
   ```bash
   rm -rf node_modules package-lock.json dist
   npm install
   npm run build
   ```

2. **Check specific platform guides:**
   - Vercel: [VERCEL_DEPLOYMENT_FIX.md](VERCEL_DEPLOYMENT_FIX.md)
   - All platforms: [DEPLOYMENT_PACKAGE.md](DEPLOYMENT_PACKAGE.md)

3. **Review detailed docs:**
   - [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md)
   - [HOSTING_PLATFORMS_COMPARISON.md](HOSTING_PLATFORMS_COMPARISON.md)

4. **Check deployment logs** for specific error messages

5. **Google the exact error message** - Often others have solved it

---

## 💡 Prevention Tips

**Before deploying:**
- ✅ Test locally first (`npm run dev`)
- ✅ Test production build (`npm run build && npm run preview`)
- ✅ Verify all environment variables
- ✅ Check browser console for errors
- ✅ Test on mobile devices

**After deploying:**
- ✅ Test all features on live site
- ✅ Check browser console for errors
- ✅ Test on multiple browsers
- ✅ Monitor deployment logs

---

**Most issues are resolved by:**
1. Setting correct environment variables
2. Configuring build settings properly
3. Clearing caches and rebuilding

**Good luck! 🚀**
