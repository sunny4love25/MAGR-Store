# 📦 GitHub & Vercel Deployment Guide

Complete step-by-step guide to deploy MAGR Store to production.

---

## 🎯 Prerequisites Checklist

Before starting, ensure you have:

- [ ] Node.js 18+ installed
- [ ] Git installed and configured
- [ ] GitHub account created
- [ ] Vercel account created (free tier works)
- [ ] Supabase account created (free tier works)
- [ ] All environment variables ready

---

## 🚀 Part 1: Prepare for GitHub

### Step 1: Initialize Git Repository

```bash
# Navigate to your project folder
cd magr-store

# Initialize git (if not already done)
git init

# Add all files
git add .

# Create initial commit
git commit -m "Initial commit - MAGR Store e-commerce platform"
```

### Step 2: Create GitHub Repository

1. Go to [github.com](https://github.com)
2. Click the **"+"** icon → **"New repository"**
3. Repository settings:
   - **Name**: `magr-store` (or your preferred name)
   - **Description**: "Modern e-commerce platform with React, TypeScript, and Supabase"
   - **Visibility**: Choose **Public** or **Private**
   - **DO NOT** initialize with README (we already have one)
4. Click **"Create repository"**

### Step 3: Push to GitHub

```bash
# Add GitHub remote (replace with your repository URL)
git remote add origin https://github.com/yourusername/magr-store.git

# Push to GitHub
git branch -M main
git push -u origin main
```

**✅ Your code is now on GitHub!**

---

## 🌐 Part 2: Set Up Supabase

### Step 1: Create Supabase Project

1. Go to [supabase.com](https://supabase.com)
2. Click **"Start your project"** → **"New Project"**
3. Project settings:
   - **Name**: `MAGR Store`
   - **Database Password**: Create a strong password (save it!)
   - **Region**: Choose closest to your users
4. Wait for project creation (~2 minutes)

### Step 2: Run Database Setup

1. In Supabase dashboard, go to **SQL Editor**
2. Click **"New Query"**
3. Copy the entire contents of `supabase-setup.sql` from your project
4. Paste into the SQL Editor
5. Click **"Run"** (bottom right)
6. Wait for success message

**✅ Database is now set up!**

### Step 3: Get Supabase Credentials

1. In Supabase dashboard, go to **Settings** → **API**
2. Copy these values (you'll need them later):
   - **Project URL** (looks like: `https://xxxxx.supabase.co`)
   - **Anon (public) key** (long string starting with `eyJ...`)

**🔒 Keep these credentials secure!**

---

## 🔐 Part 3: Generate Encryption Key

### Method 1: Using Node.js (Easiest)

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
```

Copy the output - this is your encryption key.

### Method 2: Online Generator

1. Go to [generate-random.org/encryption-key-generator](https://generate-random.org/encryption-key-generator)
2. Select **256-bit**
3. Click **Generate**
4. Copy the **Base64** key

**⚠️ Save this key securely - you'll need it for Vercel!**

---

## 🚀 Part 4: Deploy to Vercel

### Step 1: Import Project

1. Go to [vercel.com](https://vercel.com)
2. Click **"Add New"** → **"Project"**
3. Choose **"Import Git Repository"**
4. Select **GitHub** and authorize Vercel
5. Find and select your `magr-store` repository
6. Click **"Import"**

### Step 2: Configure Build Settings

Vercel should auto-detect Vite. Verify these settings:

- **Framework Preset**: Vite
- **Build Command**: `vite build` or `npm run build`
- **Output Directory**: `dist`
- **Install Command**: `npm install`

**✅ These should be pre-filled correctly!**

### Step 3: Add Environment Variables

**CRITICAL STEP** - Your app won't work without these!

1. In the **"Configure Project"** section, find **"Environment Variables"**
2. Add these variables:

| Name | Value | Where to Get It |
|------|-------|----------------|
| `VITE_SUPABASE_URL` | `https://xxxxx.supabase.co` | Supabase Settings → API |
| `VITE_SUPABASE_ANON_KEY` | `eyJhbGc...` | Supabase Settings → API |
| `VITE_ENCRYPTION_KEY` | `your-generated-key` | From Part 3 above |

**How to add:**
1. Click **"Add Variable"**
2. Enter **Name** (e.g., `VITE_SUPABASE_URL`)
3. Enter **Value** (paste your actual value)
4. Leave **"Production, Preview, Development"** checked
5. Repeat for all 3 variables

### Step 4: Deploy!

1. Click **"Deploy"**
2. Wait 1-3 minutes while Vercel builds your app
3. Watch the build logs (click **"Building"** to expand)

**🎉 Your app is now live!**

### Step 5: Get Your Live URL

After deployment:
1. You'll see **"Congratulations!"** with confetti 🎊
2. Copy your deployment URL (looks like: `https://magr-store-xxxxx.vercel.app`)
3. Click **"Visit"** to see your live site

---

## ✅ Part 5: Verify Deployment

### Test These Features:

- [ ] Site loads without errors
- [ ] Products display correctly
- [ ] Cart functionality works
- [ ] Search works
- [ ] Admin panel accessible
- [ ] No console errors

### Check Browser Console:

1. Press `F12` or `Cmd+Option+I` (Mac)
2. Go to **Console** tab
3. Look for any red errors
4. If you see Supabase errors, double-check environment variables

---

## 🔧 Part 6: Post-Deployment Setup

### Configure SMTP (Optional but Recommended)

1. Visit your live site
2. Click **Admin** icon (top right)
3. Go to **Email Settings** tab
4. Configure SMTP:
   - **Host**: `smtp.gmail.com` (for Gmail)
   - **Port**: `587`
   - **Username**: Your Gmail address
   - **Password**: [App-specific password](https://support.google.com/accounts/answer/185833)
   - **From Email**: `noreply@yourdomain.com`
   - **From Name**: `MAGR Store`
5. Click **Save Configuration**
6. Click **"Send Test Email"** to verify

### Test Email Functionality:

- [ ] Newsletter subscription works
- [ ] Vendor registration sends confirmation
- [ ] Test email sends successfully

---

## 🌍 Part 7: Custom Domain (Optional)

### Add Your Own Domain:

1. In Vercel dashboard, go to **Settings** → **Domains**
2. Click **"Add"**
3. Enter your domain (e.g., `magrstore.com`)
4. Follow Vercel's DNS configuration instructions
5. Wait for DNS propagation (up to 48 hours, usually <1 hour)

### Popular Domain Registrars:
- [Namecheap](https://namecheap.com)
- [GoDaddy](https://godaddy.com)
- [Google Domains](https://domains.google)

---

## 🐛 Troubleshooting

### Build Fails on Vercel

**Error**: `Command "npm run build" failed`

**Solutions**:
1. Check environment variables are set correctly
2. Ensure all 3 required variables are added
3. Verify variable names are EXACTLY: `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`, `VITE_ENCRYPTION_KEY`
4. Redeploy from Vercel dashboard

### Site Loads But Products Don't Show

**Cause**: Supabase not configured

**Solutions**:
1. Verify `supabase-setup.sql` was run completely
2. Check Supabase URL and key are correct
3. Check browser console for errors
4. Verify Supabase project is active

### "Failed to fetch" Errors

**Cause**: CORS or network issues

**Solutions**:
1. Check Supabase project is not paused
2. Verify environment variables in Vercel
3. Check Supabase RLS policies are set correctly

### Email Not Sending

**Cause**: SMTP not configured

**Solutions**:
1. Configure SMTP via Admin Panel
2. Use Gmail app-specific password (not regular password)
3. Check spam folder
4. Verify SMTP credentials are correct

---

## 📊 Monitoring Your Deployment

### Vercel Dashboard Metrics:

- **Analytics**: Track visitors and page views
- **Logs**: View runtime logs
- **Speed Insights**: Monitor performance
- **Bandwidth**: Track usage

### Supabase Dashboard:

- **Database**: View/edit data
- **Auth**: Manage users
- **Storage**: Manage files
- **Logs**: Debug queries

---

## 🔄 Making Updates

### To Update Your Live Site:

```bash
# Make changes to your code
git add .
git commit -m "Description of changes"
git push origin main
```

**Vercel automatically redeploys when you push to GitHub!**

---

## 🎯 Success Checklist

After following this guide, you should have:

- [x] Code on GitHub
- [x] Supabase database configured
- [x] Live site on Vercel
- [x] Environment variables set
- [x] SMTP configured (optional)
- [x] Custom domain (optional)

---

## 🔐 Security Reminders

- ✅ Never commit `.env` files to GitHub
- ✅ Keep Supabase service role key private
- ✅ Use strong passwords
- ✅ Enable 2FA on GitHub and Vercel
- ✅ Regularly update dependencies

---

## 📞 Getting Help

### If You're Stuck:

1. **Check Documentation**:
   - Read `TROUBLESHOOTING.md`
   - Review `COMMON_DEPLOYMENT_ERRORS.md`
   
2. **Check Logs**:
   - Vercel deployment logs
   - Browser console
   - Supabase logs

3. **Common Resources**:
   - [Vercel Documentation](https://vercel.com/docs)
   - [Supabase Documentation](https://supabase.com/docs)
   - [Vite Documentation](https://vitejs.dev)

---

## 🎉 You're Done!

Your MAGR Store is now:
- ✅ Live on the internet
- ✅ Backed by a database
- ✅ Automatically deploying
- ✅ Production-ready

**Share your store:** `https://your-app.vercel.app`

---

## 🚀 Next Steps

### Immediate:
1. Test all features thoroughly
2. Add real products (if applicable)
3. Configure branding and colors
4. Set up payment processing

### Soon:
1. Enable advanced features (see `TEMU_FEATURES_GUIDE.md`)
2. Set up email campaigns
3. Add custom domain
4. Configure SEO

### Later:
1. Monitor analytics
2. Gather customer feedback
3. Optimize performance
4. Scale as needed

---

**Congratulations on your deployment! 🎊**

*Your MAGR Store is now live and ready for customers!*

---

*Last Updated: October 26, 2025*
