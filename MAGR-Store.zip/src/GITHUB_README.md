# 🛍️ MAGR Store - Modern E-Commerce Platform

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/yourusername/magr-store)
[![Deploy to Netlify](https://www.netlify.com/img/deploy/button.svg)](https://app.netlify.com/start/deploy?repository=https://github.com/yourusername/magr-store)

A world-class e-commerce platform built with React, TypeScript, Tailwind CSS, and Supabase. Features include advanced product management, secure email systems, gamification, and comprehensive admin controls.

## ✨ Features

### Core E-Commerce
- 🛒 **Shopping Cart & Wishlist** - Full cart management with persistent storage
- 🔍 **Intelligent Search** - Smart product search and filtering
- 📱 **Responsive Design** - Optimized for all devices
- 💳 **Quick View Modal** - Fast product previews without page reload
- ⭐ **Product Reviews** - Customer reviews with photo uploads
- 📊 **Product Comparison** - Compare multiple products side-by-side

### Admin Features
- 🎨 **Customizable Info Banner** - Typewriter effect announcements
- 📧 **Email CRM System** - Campaign management and email tracking
- 🔐 **Secure SMTP** - AES-256 encrypted email credentials
- 👥 **Vendor Registration** - Supplier onboarding system
- 📈 **Analytics Dashboard** - Track sales and user engagement

### Gamification (Ready to Enable)
- 🎰 **Spin to Win** - Daily prize wheel for customer engagement
- 📅 **Daily Check-In** - Reward loyalty with streak bonuses
- 👥 **Referral Program** - Social sharing and rewards
- ⚡ **Flash Sales** - Time-limited deals with countdown timers
- 📦 **Bundle Deals** - Curated product bundles with savings

### Security & Performance
- 🔒 **AES-256 Encryption** - Secure credential storage
- ⚡ **Lazy Loading** - Optimized bundle splitting
- 🚀 **Code Splitting** - Fast initial load times
- 📦 **React.memo** - Performance-optimized components
- 🛡️ **Row Level Security** - Database-level protection

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ and npm
- Supabase account (free tier works)
- Git

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/magr-store.git
   cd magr-store
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   cp .env.example .env.local
   ```
   
   Edit `.env.local` and add your Supabase credentials:
   ```env
   VITE_SUPABASE_URL=your_supabase_url
   VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
   VITE_ENCRYPTION_KEY=generate_random_key
   ```

4. **Set up Supabase database**
   - Go to your Supabase project
   - Navigate to SQL Editor
   - Run the `supabase-setup.sql` file

5. **Start development server**
   ```bash
   npm run dev
   ```
   
   Open [http://localhost:5173](http://localhost:5173) in your browser.

## 📦 Deployment

### Deploy to Vercel (Recommended)

1. **Push to GitHub**
   ```bash
   git add .
   git commit -m "Initial commit"
   git push origin main
   ```

2. **Deploy to Vercel**
   - Visit [vercel.com](https://vercel.com)
   - Import your GitHub repository
   - Add environment variables from `.env.example`
   - Deploy!

3. **Set up environment variables in Vercel**
   - Go to Project Settings → Environment Variables
   - Add all variables from `.env.example`
   - Redeploy

### Deploy to Netlify

1. **Push to GitHub** (same as above)

2. **Deploy to Netlify**
   - Visit [netlify.com](https://netlify.com)
   - Import from Git
   - Build command: `npm run build`
   - Publish directory: `dist`
   - Add environment variables
   - Deploy!

## 🔧 Configuration

### Supabase Setup

1. Create a new project at [supabase.com](https://supabase.com)
2. Get your project URL and anon key from Settings → API
3. Run `supabase-setup.sql` in SQL Editor
4. Enable Row Level Security on all tables

### Email Configuration

Configure SMTP via:
- **Admin Panel** (recommended) - Configure through UI
- **Environment Variables** - Set in `.env.local`
- **Supabase Database** - Direct database configuration

### Encryption Key Generation

```bash
# Using Node.js
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"

# Or use the built-in function
# See utils/encryption.ts - generateEncryptionKey()
```

## 📚 Documentation

Comprehensive documentation is available in the repository:

- **[START_HERE.md](START_HERE.md)** - Complete setup guide
- **[DEPLOYMENT_PACKAGE.md](DEPLOYMENT_PACKAGE.md)** - Deployment instructions
- **[TEMU_FEATURES_GUIDE.md](TEMU_FEATURES_GUIDE.md)** - Advanced features guide
- **[EMAIL_CRM_DOCUMENTATION.md](EMAIL_CRM_DOCUMENTATION.md)** - Email system docs
- **[CUSTOMIZATION_GUIDE.md](CUSTOMIZATION_GUIDE.md)** - Customization options
- **[TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md)** - Common issues and fixes

## 🛠️ Technology Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS v4
- **Backend**: Supabase (PostgreSQL, Auth, Storage)
- **UI Components**: Radix UI, Shadcn/ui
- **Icons**: Lucide React
- **Charts**: Recharts
- **Animations**: Motion (Framer Motion)
- **Forms**: React Hook Form
- **Build Tool**: Vite
- **Deployment**: Vercel / Netlify

## 📁 Project Structure

```
magr-store/
├── components/          # React components
│   ├── ui/             # Shadcn UI components
│   ├── figma/          # Figma-specific components
│   └── *.tsx           # Feature components
├── contexts/           # React context providers
├── services/           # API and service functions
├── utils/              # Utility functions
├── styles/             # Global CSS styles
├── docs/               # Documentation
└── supabase/           # Supabase functions
```

## 🎮 Advanced Features (Optional)

The platform includes Temu-inspired features that are **fully coded** but **temporarily disabled** for stability. To enable:

1. Review `NEW_FEATURES_STATUS.md`
2. Follow `TEMU_FEATURES_GUIDE.md`
3. Enable features one at a time in `App.tsx`
4. Test thoroughly before deploying

Features include:
- Spin to Win gamification
- Daily check-in rewards
- Referral program
- Flash sales with urgency
- Bundle deals
- Product reviews with photos

## 🤝 Contributing

Contributions are welcome! Please:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Built with [Vite](https://vitejs.dev/)
- UI components from [Shadcn/ui](https://ui.shadcn.com/)
- Icons from [Lucide](https://lucide.dev/)
- Hosted on [Vercel](https://vercel.com) / [Netlify](https://netlify.com)
- Database by [Supabase](https://supabase.com)

## 💼 Support

For support, please:
- Read the documentation in the `/docs` folder
- Check `TROUBLESHOOTING.md` for common issues
- Review component inline documentation
- Check Supabase logs for backend issues

## 🔐 Security

- All SMTP credentials are encrypted with AES-256
- Row Level Security enabled on all database tables
- Environment variables for sensitive data
- Rate limiting on email operations
- Input validation and sanitization

## 🚀 Performance

- Lazy loading for optimal bundle size
- Code splitting for faster initial loads
- React.memo for component optimization
- Image lazy loading
- Optimized Tailwind CSS build

## 📊 Status

- ✅ **Production Ready** - Fully functional e-commerce platform
- ✅ **Zero Build Errors** - Clean builds every time
- ✅ **Mobile Optimized** - Responsive on all devices
- ✅ **SEO Ready** - Optimized for search engines
- ✅ **Documented** - Comprehensive documentation

---

**Built with ❤️ for modern e-commerce**

🌟 Star this repo if you find it helpful!
