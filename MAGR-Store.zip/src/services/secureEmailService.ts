/**
 * Secure Email Service with encryption and rate limiting
 */

import { supabase } from '../utils/supabase/info';
import { encrypt, decrypt, RateLimiter, validateEmail } from '../utils/encryption';

// Rate limiter: max 10 emails per hour per user
const emailRateLimiter = new RateLimiter(10, 3600000);

export interface SMTPConfig {
  host: string;
  port: number;
  secure: boolean;
  user: string;
  password: string;
  fromEmail: string;
  fromName: string;
}

export interface EmailOptions {
  to: string | string[];
  subject: string;
  html: string;
  text?: string;
  replyTo?: string;
}

/**
 * Get encryption key from environment or generate one
 */
function getEncryptionKey(): string {
  // In production, this should be stored securely in environment variables
  // For now, we'll use a combination of user session and a fixed key
  const baseKey = import.meta.env.VITE_ENCRYPTION_KEY || 'MAGR_STORE_ENCRYPTION_KEY_2024';
  return baseKey;
}

/**
 * Securely save SMTP configuration with encryption
 */
export async function saveSecureSMTPConfig(
  config: SMTPConfig,
  userId?: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const encryptionKey = getEncryptionKey();
    
    // Encrypt sensitive data
    const encryptedPassword = await encrypt(config.password, encryptionKey);
    const encryptedUser = await encrypt(config.user, encryptionKey);
    
    // Save to database with encrypted credentials
    const { error } = await supabase
      .from('smtp_settings')
      .upsert({
        host: config.host,
        port: config.port,
        secure: config.secure,
        user: encryptedUser,
        password: encryptedPassword,
        from_email: config.fromEmail,
        from_name: config.fromName,
        updated_by: userId,
        updated_at: new Date().toISOString(),
      });

    if (error) throw error;

    // Log the configuration change (without sensitive data)
    await logEmailActivity('smtp_config_updated', {
      host: config.host,
      port: config.port,
      from_email: config.fromEmail,
      updated_by: userId,
    });

    return { success: true };
  } catch (error) {
    console.error('Failed to save SMTP config:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Failed to save configuration'
    };
  }
}

/**
 * Retrieve and decrypt SMTP configuration
 */
export async function getSecureSMTPConfig(): Promise<SMTPConfig | null> {
  try {
    const { data, error } = await supabase
      .from('smtp_settings')
      .select('*')
      .single();

    if (error || !data) return null;

    const encryptionKey = getEncryptionKey();
    
    // Decrypt sensitive data
    const password = await decrypt(data.password, encryptionKey);
    const user = await decrypt(data.user, encryptionKey);

    return {
      host: data.host,
      port: data.port,
      secure: data.secure,
      user,
      password,
      fromEmail: data.from_email,
      fromName: data.from_name,
    };
  } catch (error) {
    console.error('Failed to retrieve SMTP config:', error);
    return null;
  }
}

/**
 * Send email with security checks and rate limiting
 */
export async function sendSecureEmail(
  options: EmailOptions,
  userId?: string
): Promise<{ success: boolean; error?: string }> {
  try {
    // Validate email addresses
    const recipients = Array.isArray(options.to) ? options.to : [options.to];
    for (const email of recipients) {
      if (!validateEmail(email)) {
        return { success: false, error: `Invalid email address: ${email}` };
      }
    }

    // Check rate limit
    const identifier = userId || recipients[0];
    if (!emailRateLimiter.checkLimit(identifier)) {
      await logEmailActivity('rate_limit_exceeded', {
        identifier,
        attempted_recipients: recipients,
      });
      return { 
        success: false, 
        error: 'Rate limit exceeded. Please try again later.' 
      };
    }

    // Get SMTP configuration
    const smtpConfig = await getSecureSMTPConfig();
    if (!smtpConfig) {
      return { success: false, error: 'SMTP not configured' };
    }

    // In a real application, you would use a proper email service here
    // For demonstration, we'll use the Supabase Edge Function approach
    const { data, error } = await supabase.functions.invoke('send-email', {
      body: {
        to: recipients,
        subject: options.subject,
        html: options.html,
        text: options.text || options.html.replace(/<[^>]*>/g, ''),
        replyTo: options.replyTo,
      },
    });

    if (error) throw error;

    // Log successful email send
    await logEmailActivity('email_sent', {
      recipients: recipients.length,
      subject: options.subject,
      sent_by: userId,
    });

    return { success: true };
  } catch (error) {
    console.error('Failed to send email:', error);
    
    // Log failed attempt
    await logEmailActivity('email_failed', {
      error: error instanceof Error ? error.message : 'Unknown error',
      attempted_by: userId,
    });

    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Failed to send email'
    };
  }
}

/**
 * Send bulk emails with batch processing and rate limiting
 */
export async function sendBulkSecureEmail(
  recipients: string[],
  subject: string,
  html: string,
  userId?: string
): Promise<{ 
  success: boolean; 
  sent: number; 
  failed: number; 
  errors?: string[] 
}> {
  const results = {
    success: true,
    sent: 0,
    failed: 0,
    errors: [] as string[],
  };

  // Process in batches of 50
  const batchSize = 50;
  for (let i = 0; i < recipients.length; i += batchSize) {
    const batch = recipients.slice(i, i + batchSize);
    
    try {
      const result = await sendSecureEmail(
        {
          to: batch,
          subject,
          html,
        },
        userId
      );

      if (result.success) {
        results.sent += batch.length;
      } else {
        results.failed += batch.length;
        if (result.error) results.errors.push(result.error);
      }
    } catch (error) {
      results.failed += batch.length;
      results.errors.push(
        error instanceof Error ? error.message : 'Batch send failed'
      );
    }

    // Add delay between batches to respect rate limits
    if (i + batchSize < recipients.length) {
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  }

  results.success = results.failed === 0;

  // Log bulk email activity
  await logEmailActivity('bulk_email_sent', {
    total_recipients: recipients.length,
    sent: results.sent,
    failed: results.failed,
    sent_by: userId,
  });

  return results;
}

/**
 * Log email activity for audit trail
 */
async function logEmailActivity(
  activity: string,
  metadata: Record<string, any>
): Promise<void> {
  try {
    await supabase.from('email_activity_log').insert({
      activity,
      metadata,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Failed to log email activity:', error);
  }
}

/**
 * Get email activity logs (for admin)
 */
export async function getEmailActivityLogs(
  limit: number = 100
): Promise<any[]> {
  try {
    const { data, error } = await supabase
      .from('email_activity_log')
      .select('*')
      .order('timestamp', { ascending: false })
      .limit(limit);

    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Failed to retrieve email logs:', error);
    return [];
  }
}

/**
 * Verify email deliverability
 */
export async function verifyEmailDeliverability(
  email: string
): Promise<{ valid: boolean; reason?: string }> {
  // Basic validation
  if (!validateEmail(email)) {
    return { valid: false, reason: 'Invalid email format' };
  }

  // Check if email is in blocklist
  const { data: blocklisted } = await supabase
    .from('email_blocklist')
    .select('email')
    .eq('email', email)
    .single();

  if (blocklisted) {
    return { valid: false, reason: 'Email is blocklisted' };
  }

  return { valid: true };
}

/**
 * Add email to blocklist
 */
export async function blockEmail(
  email: string,
  reason?: string
): Promise<void> {
  await supabase.from('email_blocklist').insert({
    email,
    reason,
    blocked_at: new Date().toISOString(),
  });
}

/**
 * Remove email from blocklist
 */
export async function unblockEmail(email: string): Promise<void> {
  await supabase.from('email_blocklist').delete().eq('email', email);
}
