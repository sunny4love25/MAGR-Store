# MAGR Store - Development Guidelines

## 🎯 Project Overview
MAGR Store is a world-class e-commerce platform with Temu-like features, advanced gamification, and enterprise-level security.

---

## 🔒 Security Guidelines (CRITICAL)

### Email & SMTP
* **ALWAYS encrypt SMTP credentials** using `utils/encryption.ts`
* **NEVER store plain-text passwords** in the database
* Use `secureEmailService` instead of direct email sending
* Implement rate limiting for all email operations (10/hour default)
* Log all email activities for audit trail
* Validate and sanitize all email inputs

### Data Protection
* Enable Row Level Security (RLS) on all Supabase tables
* Sanitize user inputs before storage using `sanitizeInput()`
* Use parameterized queries to prevent SQL injection
* Validate file uploads before processing
* Never expose API keys in client-side code

---

## 🎮 Gamification Best Practices

### Spin to Win
* Limit to one spin per user per day (localStorage + database check)
* Use probability-based prize selection
* Validate email format before allowing spin
* Track all spins in `spin_participants` table
* Send coupon codes via email immediately after win

### Daily Check-In
* Reset streaks if user misses a day
* Store in both localStorage and database for reliability
* Provide progressive rewards (higher on day 7)
* Show visual progress indicators
* Track lifetime vs current points separately

### Referral Program
* Generate unique referral codes per user
* Validate referrals aren't self-referrals
* Only credit rewards after confirmed purchase ($50+ minimum)
* Provide social sharing options (WhatsApp, Facebook, Twitter)

---

## 💻 Code Standards

### General
* Use TypeScript for all new code - types are mandatory
* Follow functional component patterns (no class components)
* Implement proper error handling with try-catch
* Add JSDoc comments to all exported functions
* Keep functions small and focused (max 50 lines)

### Performance (IMPORTANT)
* Lazy load all heavy components using `lazy()` and `Suspense`
* Use `React.memo()` for components that receive same props often
* Implement code splitting for routes
* Optimize images: WebP format, lazy loading, proper sizing
* Use dynamic imports for features not needed initially

### Styling with Tailwind
* Use Tailwind CSS utility classes
* **NEVER override typography** (font-size, font-weight, line-height) unless explicitly requested
* Mobile-first responsive design (use `md:` and `lg:` breakpoints)
* Use consistent spacing scale (4px base unit)
* Avoid inline styles unless absolutely necessary

---

## 🎨 Design System

### Colors (Brand Identity)
* Primary: Orange (#FF6B35) - main CTAs
* Secondary: Blue (#4ECDC4) - info, links
* Success: Green (#52BE80) - confirmations
* Danger: Red (#E74C3C) - errors, urgency
* Warning: Yellow (#F39C12) - alerts
* Purple (#9B59B6) - gamification

### Gradients (for Visual Impact)
* Flash Sales: `from-orange-500 to-red-500`
* Bundles: `from-green-500 to-emerald-500`
* Spin to Win: `from-purple-500 to-pink-500`
* Check-In: `from-blue-500 to-purple-500`

### Typography
* **Use default styles** from `globals.css`
* **Only override** when explicitly requested by user
* Maintain hierarchy: h1 > h2 > h3 > p
* Line height should support readability

### Components (ShadCN)
* Always use ShadCN components from `components/ui` directory
* Don't create custom versions of existing components
* Maintain consistent prop interfaces
* Add proper loading and error states

---

## 📊 Database Guidelines

### Table Design
* Use UUIDs for primary keys (`UUID DEFAULT gen_random_uuid()`)
* Always add `created_at` and `updated_at` timestamps
* Index frequently queried columns
* Use JSONB for flexible metadata fields

### Security (RLS)
* Enable Row Level Security on ALL tables
* Create policies for public vs authenticated access
* Test policies thoroughly before deployment
* Document policy logic in SQL comments

### Queries
* Use Supabase client properly (`.from()`, `.select()`, etc.)
* Handle errors gracefully with try-catch
* Implement pagination for lists (`limit()`, `range()`)
* Use `.select()` to limit returned fields (don't return everything)

---

## 🚀 Performance Guidelines

### Images
* Use `ImageWithFallback` component for all product images
* Implement lazy loading on all images
* Optimize sizes: thumbnails (200x200), medium (400x400), large (800x800)
* Use Unsplash for placeholder images

### API Calls
* Implement caching where appropriate (localStorage, React Query)
* Show loading states for all async operations
* Add retry logic for failed requests
* Handle errors with user-friendly messages (toast notifications)

### Rendering Optimization
* Use `useMemo()` for expensive calculations
* Use `useCallback()` for function props
* Implement virtualization for long lists (100+ items)
* Lazy load modals and heavy components

---

## 📱 Mobile Optimization

### Responsive Design (Mobile-First)
* Test on mobile devices (iPhone, Android)
* Touch targets minimum 44x44px
* Proper viewport settings in HTML
* Collapsible navigation for mobile
* Bottom sheets instead of modals on mobile

### Performance on Mobile
* Minimize JavaScript bundle (code splitting)
* Optimize images for mobile networks
* Reduce HTTP requests (bundle resources)
* Implement service workers for offline support

---

## 🎯 Feature-Specific Guidelines

### Flash Sales
* Always show countdown timers (use `CountdownTimer` component)
* Update stock levels in real-time
* Display "Almost Sold Out" warning when >80% sold
* Use pulsing border animations for urgency
* Auto-disable sales when time expires

### Bundle Deals
* Calculate savings automatically
* Show individual item prices for transparency
* Display total savings prominently
* Add "Free Shipping" badge for all bundles
* Track bundle performance in analytics

### Product Reviews
* Require authentication for submitting reviews
* Display "Verified Purchase" badge when applicable
* Allow up to 5 photo uploads per review
* Implement helpful voting system (prevent spam)
* Sort by: recent, helpful, highest rating

### Email Marketing
* Segment audiences based on behavior
* Personalize content (use customer name)
* A/B test subject lines
* Monitor delivery rates and bounces
* Always provide unsubscribe option

---

## 🔧 Development Workflow

### Before Committing
- [ ] Run `npm run build` - ensure no errors
- [ ] Check TypeScript errors - `tsc --noEmit`
- [ ] Test on mobile viewport
- [ ] Check browser console for warnings
- [ ] Verify all links work

### Git Commit Messages
* Use present tense: "Add feature" not "Added feature"
* Be descriptive: "Add flash sales component with countdown" not "Update"
* Reference issues when applicable: "Fix #123"

### Deployment Checklist
- [ ] Environment variables set correctly
- [ ] Database migrations run
- [ ] SMTP credentials encrypted
- [ ] RLS policies enabled
- [ ] No console errors
- [ ] Mobile tested
- [ ] Performance checked

---

## 📝 Documentation Standards

### Code Comments
```typescript
/**
 * Encrypts a string using AES-GCM encryption
 * @param plaintext - The string to encrypt
 * @param masterKey - The encryption key
 * @returns Encrypted string in base64 format
 * @throws Error if encryption fails
 */
export async function encrypt(plaintext: string, masterKey: string): Promise<string>
```

### Component Documentation
* Add prop types with TypeScript interfaces
* Document expected behavior
* Provide usage examples
* Note any side effects

---

## ⚡ Quick Reference Checklist

### Must-Haves for New Features
- [ ] TypeScript types defined
- [ ] Error handling implemented
- [ ] Loading states shown
- [ ] Mobile responsive
- [ ] Accessibility (ARIA labels, keyboard nav)
- [ ] Performance optimized (lazy loading, memoization)
- [ ] Documented (JSDoc comments)
- [ ] Tested locally

### Must-Avoids (Security)
- ❌ Plain-text sensitive data storage
- ❌ SQL injection vulnerabilities
- ❌ Hardcoded credentials or API keys
- ❌ Unvalidated user input
- ❌ Exposing internal error messages to users
- ❌ Missing authentication checks
- ❌ Disabled RLS policies
- ❌ CORS misconfiguration

### Performance Anti-Patterns
- ❌ Unnecessary re-renders
- ❌ Large bundle sizes (>500KB without code splitting)
- ❌ Blocking main thread operations
- ❌ Memory leaks (uncleared intervals, listeners)
- ❌ Unoptimized images
- ❌ Too many API calls

---

## 🎨 UI/UX Best Practices

### User Feedback
* Show loading spinners for async operations
* Display success messages (green toast)
* Show error messages (red toast with details)
* Disable buttons during processing
* Provide progress indicators for multi-step processes

### Accessibility (a11y)
* Use semantic HTML (header, nav, main, footer)
* Add ARIA labels where needed
* Ensure keyboard navigation works
* Maintain color contrast ratios (WCAG AA)
* Provide alt text for all images

### Micro-Interactions
* Button hover effects
* Smooth transitions (200-300ms)
* Loading skeletons for content
* Confetti for gamification wins
* Pulsing animations for urgency

---

## 📞 Resources & Documentation

### Main Documentation
* **Setup Guide**: START_HERE.md
* **Temu Features**: TEMU_FEATURES_GUIDE.md
* **Deployment**: DEPLOYMENT_PACKAGE.md
* **Troubleshooting**: COMMON_DEPLOYMENT_ERRORS.md
* **Database Schema**: supabase-setup.sql

### Code Examples
* Check component files for inline documentation
* All utilities have JSDoc comments
* TypeScript types are fully defined
* README files in each major directory

---

## 🏆 Quality Standards

### Before Releasing Features
1. ✅ Code passes TypeScript checks
2. ✅ No console errors or warnings
3. ✅ Works on mobile and desktop
4. ✅ Loading and error states handled
5. ✅ Accessibility standards met
6. ✅ Performance benchmarks met
7. ✅ Security review completed
8. ✅ Documentation updated

### Maintenance
* Review and update dependencies quarterly
* Monitor error logs weekly
* Check performance metrics monthly
* Update documentation with code changes
* Rotate encryption keys annually

---

**Core Principle**: Security First, User Experience Second, Features Third

**Remember**: Every feature should be secure, performant, accessible, and delightful to use.

---

*Last Updated: October 26, 2025*
*Version: 2.0 (Temu Features Update)*
