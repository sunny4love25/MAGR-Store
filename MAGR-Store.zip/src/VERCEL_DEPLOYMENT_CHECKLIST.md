# ✅ Vercel Deployment Checklist

Use this checklist to ensure everything is configured correctly before deploying.

---

## 📋 Pre-Deployment Checklist

### Local Testing
- [ ] Code runs locally: `npm run dev`
- [ ] Build succeeds locally: `npm run build`
- [ ] Preview works: `npm run preview`
- [ ] No console errors (F12)
- [ ] All features work (cart, search, etc.)

### Environment Variables Ready
- [ ] Have Supabase project URL
- [ ] Have Supabase anon key
- [ ] Created `.env.local` file locally
- [ ] Tested features with database connection

### Code Repository
- [ ] Code pushed to GitHub
- [ ] Repository is public (or Vercel has access)
- [ ] All files committed
- [ ] No sensitive data in code (API keys in .env only)

---

## 🔧 Vercel Configuration Checklist

### Project Settings

#### 1. General Settings
- [ ] Project name set
- [ ] Root Directory: `.` (or blank)
- [ ] Framework detected as: **Vite**

#### 2. Build & Development Settings

**CRITICAL - Must be exactly:**

- [ ] Framework Preset: **Vite**
- [ ] Build Command: **vite build** (or npm run build)
- [ ] Output Directory: **dist** ⚠️ NOT "build"
- [ ] Install Command: **npm install**
- [ ] Development Command: **vite** (or npm run dev)

#### 3. Environment Variables

**Required variables:**
- [ ] `VITE_SUPABASE_URL` = Your Supabase project URL
- [ ] `VITE_SUPABASE_ANON_KEY` = Your Supabase anon key

**Optional (for email features):**
- [ ] `VITE_SMTP_HOST` (if pre-configuring SMTP)
- [ ] `VITE_SMTP_PORT` (if pre-configuring SMTP)
- [ ] `VITE_SMTP_USER` (if pre-configuring SMTP)
- [ ] `VITE_SMTP_PASS` (if pre-configuring SMTP)

**Environment settings:**
- [ ] Applied to: Production, Preview, Development (all three)
- [ ] Saved successfully

#### 4. Domain Settings (Optional)
- [ ] Custom domain added (if using one)
- [ ] DNS configured
- [ ] SSL certificate active

---

## 🚀 Deployment Checklist

### Before Clicking Deploy

- [ ] Build cache cleared (if redeploying)
- [ ] All settings saved
- [ ] Environment variables verified

### During Deployment

Watch for these in build logs:

- [ ] "Cloning completed" appears
- [ ] "Running install command" succeeds
- [ ] "Running build command" succeeds
- [ ] Output shows: `dist/index.html` ✅ NOT `build/index.html` ❌
- [ ] "✓ built in X.XXs" appears
- [ ] No red error messages

### After Deployment

- [ ] Status shows: "Ready"
- [ ] Site loads at Vercel URL
- [ ] Homepage displays correctly
- [ ] Images load
- [ ] No 404 errors on navigation
- [ ] Browser console has no errors (F12)

---

## 🧪 Post-Deployment Testing Checklist

### Functionality Tests

**Homepage:**
- [ ] Hero slider works
- [ ] Product sections display
- [ ] "Load More" button works
- [ ] Images load properly

**Navigation:**
- [ ] Header navigation works
- [ ] Footer links work
- [ ] Search bar functions
- [ ] All pages accessible

**E-commerce Features:**
- [ ] Product cards display
- [ ] Quick view modal works
- [ ] Add to cart functions
- [ ] Cart sheet opens
- [ ] Wishlist works
- [ ] Compare feature works
- [ ] Currency selector works

**User Features:**
- [ ] Login/register dialog opens
- [ ] Newsletter signup works (if database connected)
- [ ] Vendor registration form accessible
- [ ] Chat widget functions

**Database Features (if Supabase connected):**
- [ ] Newsletter subscription saves to database
- [ ] Vendor registrations save
- [ ] User authentication works
- [ ] Data loads from database

**Admin Features:**
- [ ] Admin panel accessible (login required)
- [ ] Information banner editable
- [ ] Settings save correctly
- [ ] Email CRM dashboard loads

### Mobile Testing

- [ ] Site loads on mobile
- [ ] Touch interactions work
- [ ] Responsive layout correct
- [ ] No horizontal scroll
- [ ] Images fit screen
- [ ] Forms usable on mobile

### Performance Testing

- [ ] Page loads in < 3 seconds
- [ ] Images lazy load
- [ ] No layout shift
- [ ] Smooth scrolling
- [ ] Animations work

### SEO & Meta

- [ ] Page title shows correctly
- [ ] Meta description set
- [ ] Favicon appears
- [ ] Social media preview works

---

## 🐛 Troubleshooting Checklist

### If Build Fails

- [ ] Check error message in logs
- [ ] Verify Node.js version (use 18 or 20)
- [ ] Clear build cache
- [ ] Check all dependencies installed
- [ ] Try building locally first

### If "No Output Directory" Error

- [ ] Verify Output Directory = `dist` in dashboard
- [ ] Check build logs show `dist/` not `build/`
- [ ] Clear build cache
- [ ] See: [VERCEL_FIX_STEP_BY_STEP.md](VERCEL_FIX_STEP_BY_STEP.md)

### If Site Shows Blank Page

- [ ] Check browser console for errors
- [ ] Verify environment variables set
- [ ] Check Supabase project is active
- [ ] Test with incognito/private window
- [ ] Clear browser cache

### If Database Connection Fails

- [ ] Environment variables correct
- [ ] Supabase project URL format correct
- [ ] Supabase project not paused
- [ ] API keys match current project
- [ ] RLS policies configured

### If Images Don't Load

- [ ] Check image URLs valid
- [ ] CORS headers correct
- [ ] Image sources accessible
- [ ] Check network tab (F12)

---

## 📊 Success Criteria

Your deployment is successful when ALL of these are true:

### Build Success
✅ Build logs show:
```
dist/index.html
dist/assets/index-XXXXX.css
dist/assets/index-XXXXX.js
✓ built in X.XXs
```

✅ Deployment status: **"Ready"**

### Site Functionality
✅ Homepage loads completely
✅ All sections visible
✅ Images display
✅ Navigation works
✅ Cart/Wishlist function
✅ Forms work
✅ No console errors

### Performance
✅ Lighthouse score > 80
✅ Page load < 3 seconds
✅ Mobile responsive
✅ All features work on mobile

### Database (if connected)
✅ Newsletter signup saves
✅ User auth works
✅ Admin panel accessible
✅ Email features function

---

## 🎯 Common Mistakes to Avoid

❌ **DON'T:**
- Set Output Directory to "build"
- Skip clearing build cache
- Forget to add environment variables
- Deploy without testing locally
- Use wrong Supabase URL format
- Commit .env.local to Git

✅ **DO:**
- Set Output Directory to "dist"
- Clear cache before redeploying
- Add all VITE_* environment variables
- Test build locally first
- Use correct Supabase project URL
- Keep .env.local in .gitignore

---

## 📅 Deployment Workflow

**Recommended process:**

1. **Develop Locally**
   - Code new features
   - Test in dev mode
   - Check browser console

2. **Test Build**
   ```bash
   npm run build
   npm run preview
   ```

3. **Commit & Push**
   ```bash
   git add .
   git commit -m "Description"
   git push
   ```

4. **Configure Vercel** (first time only)
   - Set all build settings
   - Add environment variables
   - Configure domain (if any)

5. **Deploy**
   - Trigger deployment
   - Watch build logs
   - Verify success

6. **Test Live Site**
   - Go through checklist above
   - Test all features
   - Check on mobile

7. **Monitor**
   - Check analytics
   - Review error logs
   - Fix any issues

---

## 🔄 Redeployment Checklist

When making changes and redeploying:

- [ ] Changes committed to Git
- [ ] Changes pushed to GitHub
- [ ] Tested locally first
- [ ] Build succeeds locally
- [ ] Clear Vercel build cache (if major changes)
- [ ] Trigger redeploy
- [ ] Verify changes live
- [ ] Test affected features

---

## 📞 Need Help?

**Check these first:**
1. [VERCEL_FIX_STEP_BY_STEP.md](VERCEL_FIX_STEP_BY_STEP.md) - Step-by-step fix
2. [COMMON_DEPLOYMENT_ERRORS.md](COMMON_DEPLOYMENT_ERRORS.md) - Common issues
3. [YOUR_DEPLOYMENT_ISSUE_EXPLAINED.md](YOUR_DEPLOYMENT_ISSUE_EXPLAINED.md) - Technical explanation
4. [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) - General troubleshooting

**Still stuck?**
- Vercel Support: https://vercel.com/support
- Supabase Support: https://supabase.com/support
- GitHub Issues: Check project issues tab

---

## ✅ Final Checklist Before Going Live

### Production Ready
- [ ] All features tested and working
- [ ] Content added (products, images, text)
- [ ] Admin panel configured
- [ ] Email SMTP configured
- [ ] Database populated
- [ ] Privacy Policy reviewed
- [ ] Terms of Service reviewed
- [ ] Cookie Policy configured
- [ ] Analytics set up (optional)
- [ ] Custom domain configured (optional)
- [ ] SSL certificate active
- [ ] Mobile fully tested
- [ ] Performance optimized
- [ ] SEO meta tags set

### Legal & Compliance
- [ ] Privacy policy accurate
- [ ] Terms of service complete
- [ ] Cookie consent working
- [ ] GDPR compliance (if EU customers)
- [ ] Return policy set
- [ ] Contact information correct

### Business Ready
- [ ] Payment gateway configured (if using)
- [ ] Shipping methods set (if physical products)
- [ ] Tax settings configured
- [ ] Inventory system ready
- [ ] Customer service plan ready
- [ ] Email templates ready
- [ ] Launch announcement prepared

---

## 🎉 You're Ready!

Once everything on this checklist is ✅, you're ready to launch!

**Good luck with your MAGR Store! 🚀**

---

**Checklist Last Updated:** October 26, 2025
