import { useState, useRef } from 'react';
import { X, Gift, Sparkles } from 'lucide-react';
import { Button } from './ui/button';
import { Dialog, DialogContent } from './ui/dialog';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner@2.0.3';
import { supabase } from '../utils/supabase/info';

interface Prize {
  id: number;
  label: string;
  value: string;
  color: string;
  probability: number;
}

const prizes: Prize[] = [
  { id: 1, label: '10% OFF', value: 'SPIN10', color: '#FF6B6B', probability: 30 },
  { id: 2, label: '15% OFF', value: 'SPIN15', color: '#4ECDC4', probability: 20 },
  { id: 3, label: '20% OFF', value: 'SPIN20', color: '#45B7D1', probability: 15 },
  { id: 4, label: '25% OFF', value: 'SPIN25', color: '#F7DC6F', probability: 10 },
  { id: 5, label: 'FREE SHIP', value: 'FREESHIP', color: '#BB8FCE', probability: 15 },
  { id: 6, label: '30% OFF', value: 'SPIN30', color: '#F39C12', probability: 5 },
  { id: 7, label: '$5 OFF', value: '5DOLLARS', color: '#52BE80', probability: 3 },
  { id: 8, label: '$10 OFF', value: '10DOLLARS', color: '#E74C3C', probability: 2 },
];

export function SpinToWin() {
  const [isOpen, setIsOpen] = useState(false);
  const [isSpinning, setIsSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [wonPrize, setWonPrize] = useState<Prize | null>(null);
  const [email, setEmail] = useState('');
  const [canSpin, setCanSpin] = useState(true);
  const wheelRef = useRef<HTMLDivElement>(null);

  // Check if user can spin (once per day)
  const checkCanSpin = () => {
    const lastSpin = localStorage.getItem('lastSpinDate');
    if (lastSpin) {
      const lastSpinDate = new Date(lastSpin);
      const today = new Date();
      const diffTime = Math.abs(today.getTime() - lastSpinDate.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays >= 1;
    }
    return true;
  };

  const selectPrize = (): Prize => {
    const random = Math.random() * 100;
    let cumulative = 0;
    
    for (const prize of prizes) {
      cumulative += prize.probability;
      if (random <= cumulative) {
        return prize;
      }
    }
    
    return prizes[0];
  };

  const spinWheel = async () => {
    if (!email) {
      toast.error('Please enter your email to spin');
      return;
    }

    if (!checkCanSpin()) {
      toast.error('You can spin once per day. Come back tomorrow!');
      return;
    }

    setIsSpinning(true);
    
    // Select winning prize
    const prize = selectPrize();
    const prizeIndex = prizes.findIndex(p => p.id === prize.id);
    const segmentAngle = 360 / prizes.length;
    const prizeAngle = prizeIndex * segmentAngle;
    
    // Calculate rotation (multiple full spins + prize angle)
    const spins = 5;
    const finalRotation = rotation + (360 * spins) + (360 - prizeAngle) + (segmentAngle / 2);
    
    setRotation(finalRotation);

    // Save email to database
    try {
      await supabase.from('spin_participants').insert({
        email,
        prize_won: prize.label,
        coupon_code: prize.value,
        created_at: new Date().toISOString(),
      });
    } catch (error) {
      console.error('Error saving spin result:', error);
    }

    // Show result after animation
    setTimeout(() => {
      setIsSpinning(false);
      setWonPrize(prize);
      localStorage.setItem('lastSpinDate', new Date().toISOString());
      toast.success(`Congratulations! You won ${prize.label}!`);
    }, 5000);
  };

  const copyCode = () => {
    if (wonPrize) {
      navigator.clipboard.writeText(wonPrize.value);
      toast.success('Coupon code copied!');
    }
  };

  return (
    <>
      {/* Floating Trigger Button */}
      <motion.button
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        whileHover={{ scale: 1.1 }}
        className="fixed right-4 bottom-24 z-40 w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full shadow-lg flex items-center justify-center"
        onClick={() => setIsOpen(true)}
      >
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
        >
          <Gift className="w-8 h-8 text-white" />
        </motion.div>
      </motion.button>

      {/* Spin to Win Dialog */}
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-2xl">
          <div className="space-y-6">
            {!wonPrize ? (
              <>
                {/* Header */}
                <div className="text-center space-y-2">
                  <div className="flex items-center justify-center gap-2">
                    <Sparkles className="w-6 h-6 text-yellow-500" />
                    <h2 className="text-2xl">Spin to Win!</h2>
                    <Sparkles className="w-6 h-6 text-yellow-500" />
                  </div>
                  <p className="text-gray-600">
                    Enter your email and spin for a chance to win exclusive discounts!
                  </p>
                </div>

                {/* Wheel Container */}
                <div className="relative flex items-center justify-center p-8">
                  {/* Pointer */}
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 z-10">
                    <div className="w-0 h-0 border-l-[15px] border-l-transparent border-r-[15px] border-r-transparent border-t-[30px] border-t-red-500" />
                  </div>

                  {/* Wheel */}
                  <motion.div
                    ref={wheelRef}
                    className="relative w-80 h-80"
                    style={{
                      rotate: rotation,
                    }}
                    transition={{
                      duration: 5,
                      ease: [0.25, 0.1, 0.25, 1],
                    }}
                  >
                    {/* SVG Wheel */}
                    <svg viewBox="0 0 400 400" className="w-full h-full">
                      <circle
                        cx="200"
                        cy="200"
                        r="200"
                        fill="#1a1a1a"
                        stroke="#fff"
                        strokeWidth="4"
                      />
                      {prizes.map((prize, index) => {
                        const angle = (360 / prizes.length) * index;
                        const nextAngle = (360 / prizes.length) * (index + 1);
                        const startRad = (angle * Math.PI) / 180;
                        const endRad = (nextAngle * Math.PI) / 180;

                        const x1 = 200 + 200 * Math.cos(startRad);
                        const y1 = 200 + 200 * Math.sin(startRad);
                        const x2 = 200 + 200 * Math.cos(endRad);
                        const y2 = 200 + 200 * Math.sin(endRad);

                        const textAngle = angle + 360 / prizes.length / 2;
                        const textRad = (textAngle * Math.PI) / 180;
                        const textX = 200 + 130 * Math.cos(textRad);
                        const textY = 200 + 130 * Math.sin(textRad);

                        return (
                          <g key={prize.id}>
                            <path
                              d={`M 200 200 L ${x1} ${y1} A 200 200 0 0 1 ${x2} ${y2} Z`}
                              fill={prize.color}
                              stroke="#fff"
                              strokeWidth="2"
                            />
                            <text
                              x={textX}
                              y={textY}
                              fill="white"
                              fontSize="16"
                              fontWeight="bold"
                              textAnchor="middle"
                              dominantBaseline="middle"
                              transform={`rotate(${textAngle}, ${textX}, ${textY})`}
                            >
                              {prize.label}
                            </text>
                          </g>
                        );
                      })}
                      <circle cx="200" cy="200" r="30" fill="#fff" />
                      <circle cx="200" cy="200" r="20" fill="#1a1a1a" />
                    </svg>
                  </motion.div>
                </div>

                {/* Email Input and Spin Button */}
                <div className="space-y-4">
                  <input
                    type="email"
                    placeholder="Enter your email"
                    className="w-full px-4 py-3 border rounded-lg"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    disabled={isSpinning}
                  />
                  <Button
                    className="w-full py-6 text-lg bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
                    onClick={spinWheel}
                    disabled={isSpinning}
                  >
                    {isSpinning ? 'Spinning...' : 'SPIN NOW!'}
                  </Button>
                  <p className="text-xs text-center text-gray-500">
                    One spin per day. No purchase necessary.
                  </p>
                </div>
              </>
            ) : (
              /* Winner Screen */
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="text-center space-y-6 py-8"
              >
                <motion.div
                  animate={{ rotate: [0, 10, -10, 0] }}
                  transition={{ duration: 0.5, repeat: 3 }}
                >
                  <Gift className="w-24 h-24 mx-auto text-yellow-500" />
                </motion.div>

                <div>
                  <h2 className="text-3xl mb-2">Congratulations!</h2>
                  <p className="text-gray-600">You've won</p>
                  <div
                    className="text-5xl my-4 p-4 rounded-lg inline-block"
                    style={{ backgroundColor: wonPrize.color, color: 'white' }}
                  >
                    {wonPrize.label}
                  </div>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg space-y-2">
                  <p className="text-sm text-gray-600">Your Coupon Code:</p>
                  <div className="flex items-center gap-2 justify-center">
                    <code className="text-2xl px-4 py-2 bg-white border-2 border-dashed border-gray-300 rounded">
                      {wonPrize.value}
                    </code>
                    <Button onClick={copyCode} variant="outline">
                      Copy
                    </Button>
                  </div>
                </div>

                <p className="text-sm text-gray-600">
                  This code has been sent to {email}
                </p>

                <Button
                  className="w-full"
                  onClick={() => {
                    setIsOpen(false);
                    setWonPrize(null);
                    setEmail('');
                  }}
                >
                  Start Shopping
                </Button>
              </motion.div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
