import { useState } from 'react';
import { Users, Copy, Share2, Gift, DollarSign, Check } from 'lucide-react';
import { Button } from './ui/button';
import { Dialog, DialogContent } from './ui/dialog';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { motion } from 'motion/react';
import { toast } from 'sonner@2.0.3';

interface Referral {
  name: string;
  status: 'pending' | 'completed';
  reward: number;
  date: string;
}

export function ReferralProgram() {
  const [isOpen, setIsOpen] = useState(false);
  const [referralCode, setReferralCode] = useState('MAGR2024FRIEND');
  const [totalEarned, setTotalEarned] = useState(75);
  const [referrals, setReferrals] = useState<Referral[]>([
    { name: 'John D.', status: 'completed', reward: 25, date: '2024-10-20' },
    { name: 'Sarah M.', status: 'completed', reward: 25, date: '2024-10-18' },
    { name: 'Mike R.', status: 'completed', reward: 25, date: '2024-10-15' },
    { name: 'Emma W.', status: 'pending', reward: 0, date: '2024-10-24' },
  ]);

  const referralLink = `https://magrstore.com/ref/${referralCode}`;

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard!');
  };

  const shareReferral = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Join MAGR Store',
          text: `Use my referral code ${referralCode} to get $10 off your first purchase!`,
          url: referralLink,
        });
      } catch (error) {
        console.error('Error sharing:', error);
      }
    } else {
      copyToClipboard(referralLink);
    }
  };

  return (
    <>
      {/* Referral Button in Header/Menu */}
      <Button
        variant="outline"
        onClick={() => setIsOpen(true)}
        className="gap-2"
      >
        <Users className="w-4 h-4" />
        Refer & Earn
      </Button>

      {/* Referral Dialog */}
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-3xl">
          <div className="space-y-6">
            {/* Header */}
            <div className="text-center space-y-2">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="inline-flex p-4 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full mb-2"
              >
                <Users className="w-8 h-8 text-white" />
              </motion.div>
              <h2 className="text-3xl">Refer Friends, Earn Rewards!</h2>
              <p className="text-gray-600">
                Give $10, Get $25 for each friend who makes a purchase
              </p>
            </div>

            {/* Earnings Summary */}
            <div className="grid md:grid-cols-3 gap-4">
              <div className="p-6 bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg text-center">
                <DollarSign className="w-8 h-8 mx-auto mb-2 text-purple-600" />
                <p className="text-3xl text-purple-600">${totalEarned}</p>
                <p className="text-sm text-gray-600 mt-1">Total Earned</p>
              </div>

              <div className="p-6 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-lg text-center">
                <Users className="w-8 h-8 mx-auto mb-2 text-blue-600" />
                <p className="text-3xl text-blue-600">
                  {referrals.filter(r => r.status === 'completed').length}
                </p>
                <p className="text-sm text-gray-600 mt-1">Successful Referrals</p>
              </div>

              <div className="p-6 bg-gradient-to-br from-green-50 to-emerald-50 rounded-lg text-center">
                <Gift className="w-8 h-8 mx-auto mb-2 text-green-600" />
                <p className="text-3xl text-green-600">
                  {referrals.filter(r => r.status === 'pending').length}
                </p>
                <p className="text-sm text-gray-600 mt-1">Pending</p>
              </div>
            </div>

            {/* How It Works */}
            <div className="p-6 bg-gray-50 rounded-lg">
              <h3 className="text-lg mb-4">How It Works</h3>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="text-center space-y-2">
                  <div className="w-12 h-12 bg-purple-500 text-white rounded-full flex items-center justify-center mx-auto text-xl">
                    1
                  </div>
                  <h4 className="font-medium">Share Your Link</h4>
                  <p className="text-sm text-gray-600">
                    Send your unique referral link to friends
                  </p>
                </div>

                <div className="text-center space-y-2">
                  <div className="w-12 h-12 bg-purple-500 text-white rounded-full flex items-center justify-center mx-auto text-xl">
                    2
                  </div>
                  <h4 className="font-medium">Friend Gets $10</h4>
                  <p className="text-sm text-gray-600">
                    They get $10 off their first purchase of $50+
                  </p>
                </div>

                <div className="text-center space-y-2">
                  <div className="w-12 h-12 bg-purple-500 text-white rounded-full flex items-center justify-center mx-auto text-xl">
                    3
                  </div>
                  <h4 className="font-medium">You Get $25</h4>
                  <p className="text-sm text-gray-600">
                    Earn $25 credit when they complete their purchase
                  </p>
                </div>
              </div>
            </div>

            {/* Referral Link Section */}
            <div className="space-y-3">
              <h3 className="text-lg">Your Referral Link</h3>
              
              <div className="flex gap-2">
                <Input
                  value={referralLink}
                  readOnly
                  className="flex-1"
                />
                <Button onClick={() => copyToClipboard(referralLink)}>
                  <Copy className="w-4 h-4 mr-2" />
                  Copy
                </Button>
              </div>

              <div className="flex gap-2">
                <div className="flex-1">
                  <p className="text-sm text-gray-600 mb-2">Your Referral Code</p>
                  <div className="flex gap-2">
                    <Input
                      value={referralCode}
                      readOnly
                      className="flex-1 font-mono text-lg"
                    />
                    <Button 
                      variant="outline"
                      onClick={() => copyToClipboard(referralCode)}
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>

              {/* Social Share Buttons */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                <Button
                  variant="outline"
                  onClick={shareReferral}
                  className="gap-2"
                >
                  <Share2 className="w-4 h-4" />
                  Share
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    window.open(
                      `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(referralLink)}`,
                      '_blank'
                    );
                  }}
                  className="gap-2"
                >
                  Facebook
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    window.open(
                      `https://twitter.com/intent/tweet?text=${encodeURIComponent(`Get $10 off at MAGR Store! ${referralLink}`)}`,
                      '_blank'
                    );
                  }}
                  className="gap-2"
                >
                  Twitter
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    window.open(
                      `https://wa.me/?text=${encodeURIComponent(`Get $10 off at MAGR Store! ${referralLink}`)}`,
                      '_blank'
                    );
                  }}
                  className="gap-2"
                >
                  WhatsApp
                </Button>
              </div>
            </div>

            {/* Referral History */}
            <div>
              <h3 className="text-lg mb-4">Your Referrals</h3>
              <div className="space-y-2">
                {referrals.map((referral, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-center justify-between p-4 border rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                        {referral.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-medium">{referral.name}</p>
                        <p className="text-sm text-gray-600">
                          {new Date(referral.date).toLocaleDateString()}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      {referral.status === 'completed' ? (
                        <>
                          <Badge className="bg-green-500">
                            <Check className="w-3 h-3 mr-1" />
                            Completed
                          </Badge>
                          <p className="text-green-600 font-medium">
                            +${referral.reward}
                          </p>
                        </>
                      ) : (
                        <Badge variant="secondary">Pending</Badge>
                      )}
                    </div>
                  </motion.div>
                ))}
              </div>

              {referrals.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  <Users className="w-12 h-12 mx-auto mb-2 opacity-50" />
                  <p>No referrals yet. Start sharing your link!</p>
                </div>
              )}
            </div>

            {/* Terms */}
            <div className="p-4 bg-blue-50 rounded-lg text-sm text-gray-700">
              <p className="font-medium mb-2">Terms & Conditions:</p>
              <ul className="space-y-1 text-xs">
                <li>• Friend must be a new customer</li>
                <li>• $10 discount applies to first purchase of $50 or more</li>
                <li>• $25 reward credited after friend's purchase is confirmed</li>
                <li>• Rewards expire after 90 days if not used</li>
                <li>• Limit 100 referrals per customer per year</li>
              </ul>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
