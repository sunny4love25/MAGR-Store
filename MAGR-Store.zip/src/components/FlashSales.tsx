import { useState, useEffect } from 'react';
import { Zap, Clock, TrendingUp, ShoppingCart, Heart } from 'lucide-react';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { motion, AnimatePresence } from 'motion/react';
import { useCurrency } from '../contexts/CurrencyContext';
import { useCart } from '../contexts/CartContext';
import { useWishlist } from '../contexts/WishlistContext';
import { toast } from 'sonner@2.0.3';

interface FlashDeal {
  id: string;
  name: string;
  image: string;
  originalPrice: number;
  flashPrice: number;
  discount: number;
  stock: number;
  sold: number;
  endsAt: Date;
  category: string;
}

const mockFlashDeals: FlashDeal[] = [
  {
    id: 'flash-1',
    name: 'Wireless Earbuds Pro',
    image: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=400',
    originalPrice: 79.99,
    flashPrice: 39.99,
    discount: 50,
    stock: 100,
    sold: 67,
    endsAt: new Date(Date.now() + 2 * 60 * 60 * 1000), // 2 hours from now
    category: 'Electronics',
  },
  {
    id: 'flash-2',
    name: 'Smart Watch Series 5',
    image: 'https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=400',
    originalPrice: 299.99,
    flashPrice: 199.99,
    discount: 33,
    stock: 50,
    sold: 38,
    endsAt: new Date(Date.now() + 3 * 60 * 60 * 1000),
    category: 'Electronics',
  },
  {
    id: 'flash-3',
    name: 'Premium Leather Bag',
    image: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=400',
    originalPrice: 149.99,
    flashPrice: 89.99,
    discount: 40,
    stock: 75,
    sold: 51,
    endsAt: new Date(Date.now() + 4 * 60 * 60 * 1000),
    category: 'Fashion',
  },
  {
    id: 'flash-4',
    name: 'Running Shoes Ultra',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400',
    originalPrice: 120.00,
    flashPrice: 69.99,
    discount: 42,
    stock: 120,
    sold: 89,
    endsAt: new Date(Date.now() + 5 * 60 * 60 * 1000),
    category: 'Sports',
  },
];

export function FlashSales() {
  const [deals, setDeals] = useState<FlashDeal[]>(mockFlashDeals);
  const [timeLeft, setTimeLeft] = useState<{ [key: string]: string }>({});
  const { convertPrice, formatPrice } = useCurrency();
  const { addItem } = useCart();
  const { addItem: addToWishlist } = useWishlist();

  useEffect(() => {
    const timer = setInterval(() => {
      const newTimeLeft: { [key: string]: string } = {};
      
      deals.forEach(deal => {
        const now = new Date().getTime();
        const end = deal.endsAt.getTime();
        const distance = end - now;

        if (distance < 0) {
          newTimeLeft[deal.id] = 'ENDED';
        } else {
          const hours = Math.floor(distance / (1000 * 60 * 60));
          const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
          const seconds = Math.floor((distance % (1000 * 60)) / 1000);
          newTimeLeft[deal.id] = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        }
      });

      setTimeLeft(newTimeLeft);
    }, 1000);

    return () => clearInterval(timer);
  }, [deals]);

  const handleAddToCart = (deal: FlashDeal) => {
    addItem({
      id: deal.id,
      name: deal.name,
      price: deal.flashPrice,
      image: deal.image,
      quantity: 1,
      category: deal.category,
    });
    toast.success('Added to cart!');
  };

  const handleAddToWishlist = (deal: FlashDeal) => {
    addToWishlist({
      id: deal.id,
      name: deal.name,
      price: deal.flashPrice,
      image: deal.image,
      category: deal.category,
    });
    toast.success('Added to wishlist!');
  };

  const getStockPercentage = (deal: FlashDeal) => {
    return (deal.sold / deal.stock) * 100;
  };

  return (
    <div className="py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="bg-gradient-to-r from-orange-500 to-red-500 p-2 rounded-lg">
            <Zap className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl">Flash Sales</h2>
            <p className="text-sm text-gray-600">Limited time offers - Hurry up!</p>
          </div>
        </div>
        <div className="flex items-center gap-2 px-4 py-2 bg-red-50 rounded-lg">
          <Clock className="w-5 h-5 text-red-500" />
          <span className="text-red-600">Ends Soon</span>
        </div>
      </div>

      {/* Flash Deals Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <AnimatePresence>
          {deals.map(deal => (
            <motion.div
              key={deal.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              whileHover={{ y: -5 }}
              className="bg-white rounded-lg shadow-lg overflow-hidden border-2 border-red-200 relative"
            >
              {/* Discount Badge */}
              <Badge className="absolute top-2 left-2 z-10 bg-red-500 text-white">
                -{deal.discount}% OFF
              </Badge>

              {/* Wishlist Button */}
              <button
                onClick={() => handleAddToWishlist(deal)}
                className="absolute top-2 right-2 z-10 p-2 bg-white rounded-full shadow-md hover:bg-red-50 transition-colors"
              >
                <Heart className="w-5 h-5" />
              </button>

              {/* Product Image */}
              <div className="relative h-48 overflow-hidden bg-gray-100">
                <img
                  src={deal.image}
                  alt={deal.name}
                  className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
                />
              </div>

              <div className="p-4 space-y-3">
                {/* Product Name */}
                <h3 className="font-medium line-clamp-2 min-h-[3rem]">
                  {deal.name}
                </h3>

                {/* Price */}
                <div className="space-y-1">
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl text-red-600">
                      {formatPrice(convertPrice(deal.flashPrice))}
                    </span>
                    <span className="text-sm text-gray-400 line-through">
                      {formatPrice(convertPrice(deal.originalPrice))}
                    </span>
                  </div>
                </div>

                {/* Stock Progress */}
                <div className="space-y-1">
                  <div className="flex justify-between text-xs text-gray-600">
                    <span>Sold: {deal.sold}/{deal.stock}</span>
                    <span>{Math.round(getStockPercentage(deal))}%</span>
                  </div>
                  <Progress 
                    value={getStockPercentage(deal)} 
                    className="h-2"
                  />
                  {getStockPercentage(deal) > 80 && (
                    <p className="text-xs text-red-600 flex items-center gap-1">
                      <TrendingUp className="w-3 h-3" />
                      Almost sold out!
                    </p>
                  )}
                </div>

                {/* Countdown Timer */}
                <div className="flex items-center justify-center gap-2 p-2 bg-gradient-to-r from-orange-50 to-red-50 rounded-lg">
                  <Clock className="w-4 h-4 text-red-500" />
                  <span className="text-red-600 font-mono">
                    {timeLeft[deal.id] || '00:00:00'}
                  </span>
                </div>

                {/* Add to Cart Button */}
                <Button
                  className="w-full bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600"
                  onClick={() => handleAddToCart(deal)}
                  disabled={timeLeft[deal.id] === 'ENDED' || deal.sold >= deal.stock}
                >
                  {timeLeft[deal.id] === 'ENDED' ? (
                    'Sale Ended'
                  ) : deal.sold >= deal.stock ? (
                    'Sold Out'
                  ) : (
                    <>
                      <ShoppingCart className="w-4 h-4 mr-2" />
                      Grab It Now
                    </>
                  )}
                </Button>
              </div>

              {/* Pulsing Border Animation when low stock */}
              {getStockPercentage(deal) > 80 && timeLeft[deal.id] !== 'ENDED' && (
                <motion.div
                  className="absolute inset-0 border-2 border-red-500 rounded-lg pointer-events-none"
                  animate={{
                    opacity: [0.5, 1, 0.5],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: 'easeInOut',
                  }}
                />
              )}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* CTA Banner */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mt-8 p-6 bg-gradient-to-r from-orange-500 to-red-500 rounded-lg text-white text-center"
      >
        <h3 className="text-xl mb-2">Don't Miss Out on These Amazing Deals!</h3>
        <p className="text-sm opacity-90">
          Flash sales refresh every day with new products at incredible prices
        </p>
      </motion.div>
    </div>
  );
}
