import { useState } from 'react';
import { Package, ShoppingCart, Check, Percent } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { motion } from 'motion/react';
import { useCurrency } from '../contexts/CurrencyContext';
import { useCart } from '../contexts/CartContext';
import { toast } from 'sonner@2.0.3';

interface BundleItem {
  id: string;
  name: string;
  image: string;
  price: number;
}

interface Bundle {
  id: string;
  name: string;
  description: string;
  items: BundleItem[];
  originalPrice: number;
  bundlePrice: number;
  savings: number;
  savingsPercent: number;
  badge?: string;
}

const bundles: Bundle[] = [
  {
    id: 'bundle-1',
    name: 'Complete Home Office Setup',
    description: 'Everything you need for a productive workspace',
    items: [
      {
        id: 'item-1',
        name: 'Wireless Keyboard',
        image: 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=200',
        price: 49.99,
      },
      {
        id: 'item-2',
        name: 'Wireless Mouse',
        image: 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=200',
        price: 29.99,
      },
      {
        id: 'item-3',
        name: 'Desk Lamp',
        image: 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=200',
        price: 39.99,
      },
    ],
    originalPrice: 119.97,
    bundlePrice: 89.99,
    savings: 29.98,
    savingsPercent: 25,
    badge: 'BEST SELLER',
  },
  {
    id: 'bundle-2',
    name: 'Fitness Essentials Pack',
    description: 'Start your fitness journey with these must-haves',
    items: [
      {
        id: 'item-4',
        name: 'Yoga Mat',
        image: 'https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=200',
        price: 34.99,
      },
      {
        id: 'item-5',
        name: 'Water Bottle',
        image: 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=200',
        price: 24.99,
      },
      {
        id: 'item-6',
        name: 'Resistance Bands',
        image: 'https://images.unsplash.com/photo-1598289431512-b97b0917affc?w=200',
        price: 19.99,
      },
    ],
    originalPrice: 79.97,
    bundlePrice: 59.99,
    savings: 19.98,
    savingsPercent: 25,
  },
  {
    id: 'bundle-3',
    name: 'Gaming Setup Pro',
    description: 'Level up your gaming experience',
    items: [
      {
        id: 'item-7',
        name: 'Gaming Headset',
        image: 'https://images.unsplash.com/photo-1599669454699-248893623440?w=200',
        price: 79.99,
      },
      {
        id: 'item-8',
        name: 'Gaming Mouse Pad',
        image: 'https://images.unsplash.com/photo-1625225233840-695456021cde?w=200',
        price: 29.99,
      },
      {
        id: 'item-9',
        name: 'RGB Keyboard',
        image: 'https://images.unsplash.com/photo-1595225476474-87563907a212?w=200',
        price: 99.99,
      },
    ],
    originalPrice: 209.97,
    bundlePrice: 159.99,
    savings: 49.98,
    savingsPercent: 24,
    badge: 'HOT DEAL',
  },
];

export function BundleDeals() {
  const [selectedBundle, setSelectedBundle] = useState<string | null>(null);
  const { convertPrice, formatPrice } = useCurrency();
  const { addItem } = useCart();

  const handleAddBundle = (bundle: Bundle) => {
    // Add all items from bundle to cart
    bundle.items.forEach(item => {
      addItem({
        id: item.id,
        name: item.name,
        price: bundle.bundlePrice / bundle.items.length, // Distribute bundle price
        image: item.image,
        quantity: 1,
        category: 'Bundle',
      });
    });

    toast.success(
      <div>
        <p className="font-medium">Bundle added to cart!</p>
        <p className="text-sm">You saved {formatPrice(convertPrice(bundle.savings))}</p>
      </div>
    );
  };

  return (
    <div className="py-8">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <div className="bg-gradient-to-r from-green-500 to-emerald-500 p-2 rounded-lg">
          <Package className="w-6 h-6 text-white" />
        </div>
        <div>
          <h2 className="text-2xl">Bundle & Save</h2>
          <p className="text-sm text-gray-600">Buy more, save more on these curated bundles</p>
        </div>
      </div>

      {/* Bundles Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {bundles.map(bundle => (
          <motion.div
            key={bundle.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            whileHover={{ y: -5 }}
            className="bg-white rounded-lg shadow-lg overflow-hidden border relative"
            onMouseEnter={() => setSelectedBundle(bundle.id)}
            onMouseLeave={() => setSelectedBundle(null)}
          >
            {/* Badge */}
            {bundle.badge && (
              <Badge className="absolute top-4 right-4 z-10 bg-green-500 text-white">
                {bundle.badge}
              </Badge>
            )}

            <div className="p-6 space-y-4">
              {/* Header */}
              <div>
                <h3 className="text-lg mb-1">{bundle.name}</h3>
                <p className="text-sm text-gray-600">{bundle.description}</p>
              </div>

              {/* Bundle Items */}
              <div className="space-y-2">
                {bundle.items.map((item, index) => (
                  <motion.div
                    key={item.id}
                    initial={{ x: -20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-center gap-3 p-2 bg-gray-50 rounded-lg"
                  >
                    <div className="flex-shrink-0 w-12 h-12 bg-white rounded overflow-hidden">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm truncate">{item.name}</p>
                      <p className="text-xs text-gray-500">
                        {formatPrice(convertPrice(item.price))}
                      </p>
                    </div>
                    <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                  </motion.div>
                ))}
              </div>

              {/* Pricing */}
              <div className="space-y-2 pt-4 border-t">
                <div className="flex items-baseline gap-2">
                  <span className="text-sm text-gray-500 line-through">
                    {formatPrice(convertPrice(bundle.originalPrice))}
                  </span>
                  <Badge variant="secondary" className="text-xs">
                    <Percent className="w-3 h-3 mr-1" />
                    Save {bundle.savingsPercent}%
                  </Badge>
                </div>

                <div className="flex items-end justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Bundle Price</p>
                    <p className="text-3xl text-green-600">
                      {formatPrice(convertPrice(bundle.bundlePrice))}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-green-600">You Save</p>
                    <p className="text-lg">
                      {formatPrice(convertPrice(bundle.savings))}
                    </p>
                  </div>
                </div>
              </div>

              {/* Add to Cart Button */}
              <Button
                className="w-full bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600"
                onClick={() => handleAddBundle(bundle)}
              >
                <ShoppingCart className="w-4 h-4 mr-2" />
                Add Bundle to Cart
              </Button>

              {/* Savings Highlight */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ 
                  opacity: selectedBundle === bundle.id ? 1 : 0.6 
                }}
                className="p-3 bg-green-50 rounded-lg text-center"
              >
                <p className="text-sm text-green-700">
                  💰 You'll save{' '}
                  <span className="font-medium">
                    {formatPrice(convertPrice(bundle.savings))}
                  </span>{' '}
                  with this bundle!
                </p>
              </motion.div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Info Banner */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="mt-8 p-6 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg border border-green-200"
      >
        <div className="flex items-start gap-4">
          <div className="flex-shrink-0 p-3 bg-green-500 rounded-lg">
            <Package className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-lg mb-2">Why Buy Bundles?</h3>
            <ul className="space-y-1 text-sm text-gray-700">
              <li className="flex items-center gap-2">
                <Check className="w-4 h-4 text-green-500" />
                Save up to 25% compared to buying items separately
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-4 h-4 text-green-500" />
                Curated combinations that work perfectly together
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-4 h-4 text-green-500" />
                Free shipping on all bundle orders
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-4 h-4 text-green-500" />
                30-day money-back guarantee
              </li>
            </ul>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
