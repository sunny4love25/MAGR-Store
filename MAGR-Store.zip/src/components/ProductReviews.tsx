import { useState, useEffect } from 'react';
import { Star, ThumbsUp, Camera, Check, Filter } from 'lucide-react';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { supabase } from '../utils/supabase/info';
import { toast } from 'sonner@2.0.3';
import { motion } from 'motion/react';

interface Review {
  id: string;
  user_name: string;
  user_avatar?: string;
  rating: number;
  title: string;
  comment: string;
  images?: string[];
  helpful_count: number;
  verified_purchase: boolean;
  created_at: string;
  size?: string;
  color?: string;
}

interface ProductReviewsProps {
  productId: string;
  productName: string;
}

export function ProductReviews({ productId, productName }: ProductReviewsProps) {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [averageRating, setAverageRating] = useState(0);
  const [ratingDistribution, setRatingDistribution] = useState<number[]>([0, 0, 0, 0, 0]);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [newReview, setNewReview] = useState({
    rating: 5,
    title: '',
    comment: '',
    images: [] as string[],
  });
  const [filter, setFilter] = useState<'all' | 'verified' | 'with-photos'>('all');
  const [sortBy, setSortBy] = useState<'recent' | 'helpful' | 'rating'>('recent');

  useEffect(() => {
    loadReviews();
  }, [productId, filter, sortBy]);

  const loadReviews = async () => {
    try {
      let query = supabase
        .from('product_reviews')
        .select('*')
        .eq('product_id', productId);

      if (filter === 'verified') {
        query = query.eq('verified_purchase', true);
      } else if (filter === 'with-photos') {
        query = query.not('images', 'is', null);
      }

      if (sortBy === 'recent') {
        query = query.order('created_at', { ascending: false });
      } else if (sortBy === 'helpful') {
        query = query.order('helpful_count', { ascending: false });
      } else if (sortBy === 'rating') {
        query = query.order('rating', { ascending: false });
      }

      const { data, error } = await query;

      if (error) throw error;

      setReviews(data || []);
      calculateRatingStats(data || []);
    } catch (error) {
      console.error('Error loading reviews:', error);
    }
  };

  const calculateRatingStats = (reviewData: Review[]) => {
    if (reviewData.length === 0) return;

    const total = reviewData.reduce((sum, review) => sum + review.rating, 0);
    setAverageRating(total / reviewData.length);

    const distribution = [0, 0, 0, 0, 0];
    reviewData.forEach(review => {
      distribution[review.rating - 1]++;
    });
    setRatingDistribution(distribution);
  };

  const submitReview = async () => {
    if (!newReview.title || !newReview.comment) {
      toast.error('Please fill in all fields');
      return;
    }

    try {
      const { error } = await supabase.from('product_reviews').insert({
        product_id: productId,
        user_name: 'Anonymous', // In real app, get from auth
        rating: newReview.rating,
        title: newReview.title,
        comment: newReview.comment,
        images: newReview.images,
        verified_purchase: false, // Check from orders table in real app
        helpful_count: 0,
        created_at: new Date().toISOString(),
      });

      if (error) throw error;

      toast.success('Review submitted successfully!');
      setShowReviewForm(false);
      setNewReview({ rating: 5, title: '', comment: '', images: [] });
      loadReviews();
    } catch (error) {
      console.error('Error submitting review:', error);
      toast.error('Failed to submit review');
    }
  };

  const markHelpful = async (reviewId: string) => {
    try {
      const review = reviews.find(r => r.id === reviewId);
      if (!review) return;

      const { error } = await supabase
        .from('product_reviews')
        .update({ helpful_count: review.helpful_count + 1 })
        .eq('id', reviewId);

      if (error) throw error;

      loadReviews();
    } catch (error) {
      console.error('Error marking helpful:', error);
    }
  };

  return (
    <div className="space-y-6">
      {/* Rating Summary */}
      <div className="grid md:grid-cols-2 gap-6 p-6 border rounded-lg">
        <div className="flex flex-col items-center justify-center space-y-2">
          <div className="text-5xl">{averageRating.toFixed(1)}</div>
          <div className="flex items-center gap-1">
            {[1, 2, 3, 4, 5].map(star => (
              <Star
                key={star}
                className={`w-5 h-5 ${
                  star <= Math.round(averageRating)
                    ? 'fill-yellow-400 text-yellow-400'
                    : 'text-gray-300'
                }`}
              />
            ))}
          </div>
          <div className="text-sm text-gray-600">
            Based on {reviews.length} reviews
          </div>
          <Button onClick={() => setShowReviewForm(true)} className="mt-4">
            Write a Review
          </Button>
        </div>

        <div className="space-y-2">
          {[5, 4, 3, 2, 1].map(rating => (
            <div key={rating} className="flex items-center gap-2">
              <div className="flex items-center gap-1 w-20">
                <span className="text-sm">{rating}</span>
                <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
              </div>
              <Progress
                value={(ratingDistribution[rating - 1] / reviews.length) * 100 || 0}
                className="flex-1"
              />
              <span className="text-sm text-gray-600 w-12 text-right">
                {ratingDistribution[rating - 1]}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Review Form */}
      {showReviewForm && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-6 border rounded-lg space-y-4"
        >
          <h3 className="text-lg">Write Your Review</h3>
          
          <div>
            <label className="block text-sm mb-2">Rating</label>
            <div className="flex gap-2">
              {[1, 2, 3, 4, 5].map(star => (
                <Star
                  key={star}
                  className={`w-8 h-8 cursor-pointer transition-colors ${
                    star <= newReview.rating
                      ? 'fill-yellow-400 text-yellow-400'
                      : 'text-gray-300'
                  }`}
                  onClick={() => setNewReview({ ...newReview, rating: star })}
                />
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm mb-2">Review Title</label>
            <input
              type="text"
              className="w-full px-4 py-2 border rounded-lg"
              placeholder="Sum up your experience..."
              value={newReview.title}
              onChange={e => setNewReview({ ...newReview, title: e.target.value })}
            />
          </div>

          <div>
            <label className="block text-sm mb-2">Your Review</label>
            <Textarea
              className="min-h-[120px]"
              placeholder="Share your thoughts about this product..."
              value={newReview.comment}
              onChange={e => setNewReview({ ...newReview, comment: e.target.value })}
            />
          </div>

          <div className="flex gap-2">
            <Button onClick={submitReview}>Submit Review</Button>
            <Button variant="outline" onClick={() => setShowReviewForm(false)}>
              Cancel
            </Button>
          </div>
        </motion.div>
      )}

      {/* Filters */}
      <div className="flex flex-wrap gap-2">
        <Button
          variant={filter === 'all' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setFilter('all')}
        >
          All Reviews
        </Button>
        <Button
          variant={filter === 'verified' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setFilter('verified')}
        >
          <Check className="w-4 h-4 mr-1" />
          Verified Purchase
        </Button>
        <Button
          variant={filter === 'with-photos' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setFilter('with-photos')}
        >
          <Camera className="w-4 h-4 mr-1" />
          With Photos
        </Button>
        <div className="ml-auto">
          <select
            className="px-4 py-2 border rounded-lg text-sm"
            value={sortBy}
            onChange={e => setSortBy(e.target.value as any)}
          >
            <option value="recent">Most Recent</option>
            <option value="helpful">Most Helpful</option>
            <option value="rating">Highest Rating</option>
          </select>
        </div>
      </div>

      {/* Reviews List */}
      <div className="space-y-4">
        {reviews.map(review => (
          <motion.div
            key={review.id}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="p-6 border rounded-lg space-y-3"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarImage src={review.user_avatar} />
                  <AvatarFallback>{review.user_name[0]}</AvatarFallback>
                </Avatar>
                <div>
                  <div className="flex items-center gap-2">
                    <span>{review.user_name}</span>
                    {review.verified_purchase && (
                      <Badge variant="secondary" className="text-xs">
                        <Check className="w-3 h-3 mr-1" />
                        Verified Purchase
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <div className="flex">
                      {[1, 2, 3, 4, 5].map(star => (
                        <Star
                          key={star}
                          className={`w-4 h-4 ${
                            star <= review.rating
                              ? 'fill-yellow-400 text-yellow-400'
                              : 'text-gray-300'
                          }`}
                        />
                      ))}
                    </div>
                    <span>•</span>
                    <span>{new Date(review.created_at).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h4>{review.title}</h4>
              <p className="text-gray-700 mt-1">{review.comment}</p>
            </div>

            {review.size && review.color && (
              <div className="flex gap-4 text-sm text-gray-600">
                <span>Size: {review.size}</span>
                <span>Color: {review.color}</span>
              </div>
            )}

            {review.images && review.images.length > 0 && (
              <div className="flex gap-2">
                {review.images.map((image, idx) => (
                  <img
                    key={idx}
                    src={image}
                    alt="Review"
                    className="w-20 h-20 object-cover rounded-lg cursor-pointer hover:opacity-80"
                  />
                ))}
              </div>
            )}

            <div className="flex items-center gap-2 pt-2 border-t">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => markHelpful(review.id)}
                className="gap-1"
              >
                <ThumbsUp className="w-4 h-4" />
                Helpful ({review.helpful_count})
              </Button>
            </div>
          </motion.div>
        ))}
      </div>

      {reviews.length === 0 && (
        <div className="text-center py-12 text-gray-500">
          <p>No reviews yet. Be the first to review this product!</p>
        </div>
      )}
    </div>
  );
}
