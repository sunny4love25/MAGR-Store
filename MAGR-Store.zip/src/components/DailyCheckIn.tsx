import { useState, useEffect } from 'react';
import { Calendar, Gift, Coins, Trophy, Star } from 'lucide-react';
import { Button } from './ui/button';
import { Dialog, DialogContent } from './ui/dialog';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner@2.0.3';
import { supabase } from '../utils/supabase/info';

interface CheckInReward {
  day: number;
  points: number;
  bonus?: string;
  icon: React.ReactNode;
}

const rewards: CheckInReward[] = [
  { day: 1, points: 10, icon: <Coins className="w-6 h-6" /> },
  { day: 2, points: 20, icon: <Coins className="w-6 h-6" /> },
  { day: 3, points: 30, icon: <Coins className="w-6 h-6" /> },
  { day: 4, points: 40, icon: <Coins className="w-6 h-6" /> },
  { day: 5, points: 50, bonus: '5% Coupon', icon: <Gift className="w-6 h-6" /> },
  { day: 6, points: 60, icon: <Coins className="w-6 h-6" /> },
  { day: 7, points: 100, bonus: 'Free Shipping', icon: <Trophy className="w-6 h-6" /> },
];

export function DailyCheckIn() {
  const [isOpen, setIsOpen] = useState(false);
  const [currentStreak, setCurrentStreak] = useState(0);
  const [totalPoints, setTotalPoints] = useState(0);
  const [canCheckIn, setCanCheckIn] = useState(true);
  const [showReward, setShowReward] = useState(false);
  const [todayReward, setTodayReward] = useState<CheckInReward | null>(null);

  useEffect(() => {
    loadCheckInStatus();
  }, []);

  const loadCheckInStatus = async () => {
    try {
      const lastCheckIn = localStorage.getItem('lastCheckIn');
      const streak = parseInt(localStorage.getItem('checkInStreak') || '0');
      const points = parseInt(localStorage.getItem('totalPoints') || '0');

      setCurrentStreak(streak);
      setTotalPoints(points);

      if (lastCheckIn) {
        const lastDate = new Date(lastCheckIn);
        const today = new Date();
        const diffTime = Math.abs(today.getTime() - lastDate.getTime());
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

        if (diffDays < 1) {
          setCanCheckIn(false);
        } else if (diffDays > 1) {
          // Streak broken
          setCurrentStreak(0);
          localStorage.setItem('checkInStreak', '0');
        }
      }
    } catch (error) {
      console.error('Error loading check-in status:', error);
    }
  };

  const handleCheckIn = async () => {
    if (!canCheckIn) {
      toast.error('You have already checked in today!');
      return;
    }

    const newStreak = (currentStreak % 7) + 1;
    const reward = rewards[newStreak - 1];
    
    const newTotalPoints = totalPoints + reward.points;

    // Save to localStorage
    localStorage.setItem('lastCheckIn', new Date().toISOString());
    localStorage.setItem('checkInStreak', newStreak.toString());
    localStorage.setItem('totalPoints', newTotalPoints.toString());

    // Save to database
    try {
      await supabase.from('user_check_ins').insert({
        user_id: 'guest', // Replace with actual user ID
        streak: newStreak,
        points_earned: reward.points,
        bonus_reward: reward.bonus,
        checked_in_at: new Date().toISOString(),
      });
    } catch (error) {
      console.error('Error saving check-in:', error);
    }

    setCurrentStreak(newStreak);
    setTotalPoints(newTotalPoints);
    setTodayReward(reward);
    setCanCheckIn(false);
    setShowReward(true);

    setTimeout(() => {
      setShowReward(false);
    }, 3000);
  };

  return (
    <>
      {/* Floating Check-In Button */}
      <motion.button
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        whileHover={{ scale: 1.1 }}
        className="fixed left-4 bottom-24 z-40 w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full shadow-lg flex items-center justify-center"
        onClick={() => setIsOpen(true)}
      >
        <motion.div
          animate={canCheckIn ? { scale: [1, 1.2, 1] } : {}}
          transition={{ duration: 1, repeat: Infinity }}
        >
          <Calendar className="w-8 h-8 text-white" />
        </motion.div>
        {canCheckIn && (
          <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full animate-pulse" />
        )}
      </motion.button>

      {/* Check-In Dialog */}
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-2xl">
          <div className="space-y-6">
            {/* Header */}
            <div className="text-center space-y-2">
              <div className="flex items-center justify-center gap-2">
                <Calendar className="w-8 h-8 text-blue-500" />
                <h2 className="text-2xl">Daily Check-In</h2>
              </div>
              <p className="text-gray-600">
                Check in every day to earn points and unlock rewards!
              </p>
            </div>

            {/* Points Display */}
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Coins className="w-5 h-5 text-blue-500" />
                  <span className="text-sm text-gray-600">Total Points</span>
                </div>
                <p className="text-3xl text-blue-600">{totalPoints}</p>
              </div>
              <div className="p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Star className="w-5 h-5 text-purple-500" />
                  <span className="text-sm text-gray-600">Current Streak</span>
                </div>
                <p className="text-3xl text-purple-600">{currentStreak} days</p>
              </div>
            </div>

            {/* Check-In Calendar */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg">7-Day Rewards</h3>
                <Progress value={(currentStreak / 7) * 100} className="w-32" />
              </div>

              <div className="grid grid-cols-7 gap-2">
                {rewards.map(reward => (
                  <motion.div
                    key={reward.day}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: reward.day * 0.05 }}
                    className={`relative p-4 rounded-lg text-center ${
                      reward.day <= currentStreak
                        ? 'bg-gradient-to-r from-blue-500 to-purple-500 text-white'
                        : 'bg-gray-100'
                    }`}
                  >
                    {reward.day <= currentStreak && (
                      <div className="absolute top-1 right-1">
                        <div className="w-2 h-2 bg-green-400 rounded-full" />
                      </div>
                    )}

                    <div className="flex justify-center mb-2">
                      {reward.icon}
                    </div>

                    <p className="text-xs mb-1">Day {reward.day}</p>
                    <p className="text-sm">+{reward.points}</p>
                    {reward.bonus && (
                      <Badge className="mt-1 text-xs" variant="secondary">
                        {reward.bonus}
                      </Badge>
                    )}

                    {reward.day === currentStreak + 1 && canCheckIn && (
                      <motion.div
                        className="absolute inset-0 border-2 border-blue-500 rounded-lg"
                        animate={{ opacity: [0.5, 1, 0.5] }}
                        transition={{ duration: 1.5, repeat: Infinity }}
                      />
                    )}
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Check-In Button */}
            <Button
              className="w-full py-6 text-lg bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 disabled:opacity-50"
              onClick={handleCheckIn}
              disabled={!canCheckIn}
            >
              {canCheckIn ? (
                <>
                  <Calendar className="w-5 h-5 mr-2" />
                  Check In Now
                </>
              ) : (
                <>
                  ✓ Checked In Today
                </>
              )}
            </Button>

            {/* Reward Info */}
            <div className="p-4 bg-blue-50 rounded-lg space-y-2 text-sm">
              <h4 className="font-medium">How it works:</h4>
              <ul className="space-y-1 text-gray-700">
                <li>• Check in daily to earn points and maintain your streak</li>
                <li>• Complete 7 days for special bonus rewards</li>
                <li>• Use points for discounts on your purchases</li>
                <li>• Missing a day resets your streak</li>
              </ul>
            </div>
          </div>

          {/* Reward Animation */}
          <AnimatePresence>
            {showReward && todayReward && (
              <motion.div
                initial={{ opacity: 0, scale: 0 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0 }}
                className="absolute inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm rounded-lg"
              >
                <motion.div
                  initial={{ y: 50 }}
                  animate={{ y: 0 }}
                  className="bg-white p-8 rounded-2xl text-center space-y-4 max-w-sm"
                >
                  <motion.div
                    animate={{ rotate: [0, 10, -10, 0], scale: [1, 1.2, 1] }}
                    transition={{ duration: 0.5, repeat: 2 }}
                  >
                    <Gift className="w-16 h-16 mx-auto text-blue-500" />
                  </motion.div>

                  <div>
                    <h3 className="text-2xl mb-2">Congratulations!</h3>
                    <p className="text-gray-600">You earned</p>
                    <p className="text-4xl text-blue-600 my-2">
                      +{todayReward.points} Points
                    </p>
                    {todayReward.bonus && (
                      <Badge className="mt-2 text-lg py-1 px-3">
                        Bonus: {todayReward.bonus}
                      </Badge>
                    )}
                  </div>

                  <p className="text-sm text-gray-600">
                    Come back tomorrow to continue your streak!
                  </p>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </DialogContent>
      </Dialog>
    </>
  );
}
