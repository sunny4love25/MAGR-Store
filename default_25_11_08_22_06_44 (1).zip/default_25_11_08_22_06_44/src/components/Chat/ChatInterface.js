import React, { useEffect, useRef, useState } from 'react';
import MessageBubble from './MessageBubble';
import { useChat } from '../../hooks/useChat';
import { fetchTags } from '../../api/tagService';

function ChatInterface() {
  const {
    messages,
    sendMessage,
    loading,
    error,
    clearError,
  } = useChat();
  const [input, setInput] = useState('');
  const [tags, setTags] = useState([]);
  const [selectedTags, setSelectedTags] = useState([]);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    async function loadTags() {
      try {
        const fetchedTags = await fetchTags();
        setTags(fetchedTags);
      } catch {
        // silently fail - tags are optional for chat context
      }
    }
    loadTags();
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  function toggleTag(tag) {
    if (selectedTags.includes(tag)) {
      setSelectedTags(selectedTags.filter((t) => t !== tag));
    } else {
      setSelectedTags([...selectedTags, tag]);
    }
  }

  async function handleSubmit(e) {
    e.preventDefault();
    clearError();
    if (!input.trim()) return;
    try {
      await sendMessage(input.trim(), selectedTags);
      setInput('');
      setSelectedTags([]);
    } catch {
      // error handled in hook, no extra UI needed here
    }
  }

  return (
    <div className="flex flex-col h-[75vh] bg-white rounded shadow p-4">
      <h1 className="text-3xl font-bold mb-4 text-primary">AI Assistant Chat</h1>

      {tags.length > 0 && (
        <div className="mb-4 flex flex-wrap gap-2">
          {tags.map((tag) => (
            <button
              key={tag}
              type="button"
              onClick={() => toggleTag(tag)}
              className={`px-3 py-1 rounded-full border font-semibold text-sm select-none transition-colors
                ${
                  selectedTags.includes(tag)
                    ? 'bg-primary text-white border-primary'
                    : 'bg-gray-100 text-gray-700 border-gray-300 hover:bg-primary hover:text-white'
                }
              `}
              aria-pressed={selectedTags.includes(tag)}
            >
              {tag}
            </button>
          ))}
        </div>
      )}

      <div
        role="log"
        aria-live="polite"
        aria-relevant="additions"
        className="flex-grow overflow-y-auto mb-4 px-2 py-1 border border-gray-200 rounded"
      >
        {messages.length === 0 && (
          <p className="text-center text-gray-400 mt-6 select-none">
            Start chatting by typing your message below.
          </p>
        )}
        {messages.map((msg) => (
          <MessageBubble key={msg.id} message={msg} />
        ))}
        <div ref={messagesEndRef} />
      </div>

      {error && (
        <div
          role="alert"
          className="mb-3 text-red-700 bg-red-100 border border-red-400 rounded px-3 py-2 font-semibold select-none"
        >
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="flex gap-2" aria-label="Send message form">
        <textarea
          aria-label="Chat message input"
          className="flex-grow resize-none border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary"
          rows={2}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          disabled={loading}
          placeholder="Type your message..."
          required
        />
        <button
          type="submit"
          disabled={loading || input.trim() === ''}
          className="bg-primary text-white px-6 py-2 rounded font-semibold hover:bg-secondary transition-colors disabled:opacity-50"
          aria-disabled={loading || input.trim() === ''}
        >
          {loading ? 'Sending...' : 'Send'}
        </button>
      </form>
    </div>
  );
}

export default ChatInterface;
