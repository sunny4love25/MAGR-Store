import React from 'react';
import { format } from 'date-fns';
import { marked } from 'marked';

const userAvatarUrl = 'https://i.pravatar.cc/40?img=3';
const botAvatarUrl = 'https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?auto=format&fit=crop&w=40&q=80';

function MessageBubble({ message }) {
  const isUser = message.sender === 'user';

  const formattedTime = message.timestamp
    ? format(new Date(message.timestamp), 'p, MMM d')
    : '';

  return (
    <div
      className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-4`}
      aria-live="polite"
    >
      {!isUser && (
        <img
          src={botAvatarUrl}
          alt="AI assistant avatar"
          className="w-10 h-10 rounded-full mr-3 flex-shrink-0"
          loading="lazy"
        />
      )}
      <div
        className={`max-w-[70%] px-4 py-3 rounded-lg whitespace-pre-wrap break-words
          ${isUser ? 'bg-chatUser text-white rounded-br-none' : 'bg-chatBot text-gray-100 rounded-bl-none'}
        `}
        role="article"
        aria-label={isUser ? 'User message' : 'AI assistant message'}
        dangerouslySetInnerHTML={{ __html: marked.parse(message.text || '') }}
      />
      {isUser && (
        <img
          src={userAvatarUrl}
          alt="User avatar"
          className="w-10 h-10 rounded-full ml-3 flex-shrink-0"
          loading="lazy"
        />
      )}
      <span
        className={`text-xs text-gray-500 self-end ${isUser ? 'mr-2' : 'ml-2'}`}
        aria-hidden="true"
      >
        {formattedTime}
      </span>
    </div>
  );
}

export default React.memo(MessageBubble);
