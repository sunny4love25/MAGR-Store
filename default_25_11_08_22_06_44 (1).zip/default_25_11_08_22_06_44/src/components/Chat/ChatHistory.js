import React, { useEffect, useState } from 'react';
import { fetchChatHistories, fetchChatHistoryById, deleteChatHistory } from '../../api/chatService';
import MessageBubble from './MessageBubble';

function ChatHistory() {
  const [histories, setHistories] = useState([]);
  const [selectedHistory, setSelectedHistory] = useState(null);
  const [loadingHistories, setLoadingHistories] = useState(true);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    async function loadHistories() {
      setLoadingHistories(true);
      setError('');
      try {
        const data = await fetchChatHistories();
        setHistories(data);
      } catch (err) {
        setError(err.message || 'Failed to load chat histories.');
      } finally {
        setLoadingHistories(false);
      }
    }
    loadHistories();
  }, []);

  async function handleSelectHistory(id) {
    setError('');
    setLoadingMessages(true);
    try {
      const historyData = await fetchChatHistoryById(id);
      setSelectedHistory(historyData);
    } catch (err) {
      setError(err.message || 'Failed to load chat history.');
    } finally {
      setLoadingMessages(false);
    }
  }

  async function handleDeleteHistory(id) {
    if (
      !window.confirm(
        'Are you sure you want to delete this chat history? This action cannot be undone.'
      )
    ) {
      return;
    }
    setError('');
    try {
      await deleteChatHistory(id);
      setHistories(histories.filter((h) => h.id !== id));
      if (selectedHistory && selectedHistory.id === id) {
        setSelectedHistory(null);
      }
    } catch (err) {
      setError(err.message || 'Failed to delete chat history.');
    }
  }

  return (
    <div className="flex flex-col md:flex-row gap-6">
      <section className="md:w-1/3 bg-white rounded shadow p-4 max-h-[75vh] overflow-y-auto">
        <h2 className="text-xl font-semibold mb-4 text-primary">Chat Histories</h2>
        {loadingHistories ? (
          <p className="text-center text-gray-500 select-none">Loading histories...</p>
        ) : histories.length === 0 ? (
          <p className="text-center text-gray-500 select-none">No chat histories found.</p>
        ) : (
          <ul className="divide-y divide-gray-200">
            {histories.map(({ id, title, lastUpdated }) => (
              <li
                key={id}
                className={`flex justify-between items-center py-2 cursor-pointer hover:bg-gray-100 rounded ${
                  selectedHistory?.id === id ? 'bg-gray-200 font-semibold' : ''
                }`}
              >
                <button
                  onClick={() => handleSelectHistory(id)}
                  className="text-left truncate w-full"
                  aria-current={selectedHistory?.id === id ? 'true' : undefined}
                >
                  {title || `Chat on ${new Date(lastUpdated).toLocaleDateString()}`}
                </button>
                <button
                  onClick={() => handleDeleteHistory(id)}
                  aria-label={`Delete chat history titled: ${title || 'Untitled chat'}`}
                  className="ml-2 text-red-600 hover:text-red-800 focus:outline-none focus:ring-2 focus:ring-red-400 rounded"
                  type="button"
                >
                  &times;
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="md:w-2/3 bg-white rounded shadow p-4 max-h-[75vh] overflow-y-auto flex flex-col">
        <h2 className="text-xl font-semibold mb-4 text-primary">Chat Conversation</h2>
        {loadingMessages ? (
          <p className="text-center text-gray-500 select-none">Loading messages...</p>
        ) : !selectedHistory ? (
          <p className="text-center text-gray-400 select-none mt-10">Select a chat history to view.</p>
        ) : selectedHistory.messages.length === 0 ? (
          <p className="text-center text-gray-400 select-none mt-10">No messages in this chat.</p>
        ) : (
          <div className="flex flex-col gap-3 overflow-y-auto">
            {selectedHistory.messages.map((msg) => (
              <MessageBubble key={msg.id} message={msg} />
            ))}
          </div>
        )}
      </section>

      {error && (
        <div
          role="alert"
          className="fixed bottom-4 left-1/2 transform -translate-x-1/2 bg-red-100 text-red-700 border border-red-400 rounded px-4 py-2 font-semibold max-w-md w-full text-center select-none"
        >
          {error}
        </div>
      )}
    </div>
  );
}

export default ChatHistory;
