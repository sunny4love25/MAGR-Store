import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { Menu } from '@headlessui/react';
import { ChevronDownIcon } from '@heroicons/react/20/solid';

function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  async function handleLogout() {
    try {
      await logout();
      navigate('/login');
    } catch {
      // ignore logout errors here
    }
  }

  return (
    <nav className="bg-white shadow sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <Link to="/" className="text-2xl font-bold text-primary hover:text-secondary">
          MAGR Solutions
        </Link>
        <div className="flex items-center space-x-4">
          {user ? (
            <>
              <Link
                to="/"
                className="text-gray-700 hover:text-primary font-semibold"
                aria-current={window.location.pathname === '/' ? 'page' : undefined}
              >
                Chat
              </Link>
              <Link
                to="/history"
                className="text-gray-700 hover:text-primary font-semibold"
                aria-current={window.location.pathname === '/history' ? 'page' : undefined}
              >
                History
              </Link>
              <Menu as="div" className="relative inline-block text-left">
                <Menu.Button className="inline-flex justify-center items-center gap-1 rounded-md bg-gray-100 px-3 py-1 text-sm font-medium text-gray-700 hover:bg-gray-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-opacity-75">
                  {user.name || user.email}
                  <ChevronDownIcon className="w-4 h-4" aria-hidden="true" />
                </Menu.Button>
                <Menu.Items className="absolute right-0 mt-2 w-36 origin-top-right rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none z-50">
                  <div className="py-1">
                    <Menu.Item>
                      {({ active }) => (
                        <button
                          onClick={handleLogout}
                          className={`${
                            active ? 'bg-primary text-white' : 'text-gray-700'
                          } block w-full text-left px-4 py-2 text-sm`}
                        >
                          Logout
                        </button>
                      )}
                    </Menu.Item>
                  </div>
                </Menu.Items>
              </Menu>
            </>
          ) : (
            <>
              <Link
                to="/login"
                className="text-gray-700 hover:text-primary font-semibold"
                aria-current={window.location.pathname === '/login' ? 'page' : undefined}
              >
                Login
              </Link>
              <Link
                to="/register"
                className="text-gray-700 hover:text-primary font-semibold"
                aria-current={window.location.pathname === '/register' ? 'page' : undefined}
              >
                Register
              </Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
