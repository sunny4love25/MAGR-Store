import React, { createContext, useContext, useEffect, useState } from 'react';
import { loginUser, logoutUser, registerUser } from '../api/authService';
import jwtDecode from 'jwt-decode';

const AuthContext = createContext(null);

function parseToken(token) {
  try {
    return jwtDecode(token);
  } catch {
    return null;
  }
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem('magr_token');
    if (token) {
      const decoded = parseToken(token);
      if (decoded && decoded.exp * 1000 > Date.now()) {
        setUser({ id: decoded.sub, email: decoded.email, name: decoded.name || decoded.email });
      } else {
        localStorage.removeItem('magr_token');
        setUser(null);
      }
    }
  }, []);

  async function login(credentials) {
    const data = await loginUser(credentials);
    if (!data.token) {
      throw new Error('No token received from server');
    }
    localStorage.setItem('magr_token', data.token);
    const decoded = parseToken(data.token);
    if (!decoded) throw new Error('Invalid token received');
    setUser({ id: decoded.sub, email: decoded.email, name: decoded.name || decoded.email });
  }

  async function register(userData) {
    await registerUser(userData);
  }

  async function logout() {
    await logoutUser();
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, login, logout, register }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
}
