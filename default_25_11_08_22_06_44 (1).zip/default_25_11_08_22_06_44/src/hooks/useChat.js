import { useState, useCallback } from 'react';
import { sendMessageToAI } from '../api/chatService';
import { v4 as uuidv4 } from 'uuid';

export function useChat() {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const clearError = useCallback(() => setError(''), []);

  const sendMessage = useCallback(
    async (text, tags = []) => {
      if (!text) return;

      clearError();
      setLoading(true);

      const userMessage = {
        id: uuidv4(),
        text,
        sender: 'user',
        timestamp: new Date().toISOString(),
      };

      setMessages((prev) => [...prev, userMessage]);

      try {
        const reply = await sendMessageToAI(text, tags);
        const botMessage = {
          id: uuidv4(),
          text: reply,
          sender: 'bot',
          timestamp: new Date().toISOString(),
        };
        setMessages((prev) => [...prev, botMessage]);
      } catch (err) {
        setError(err.message || 'Failed to send message.');
        setMessages((prev) => prev.filter((m) => m.id !== userMessage.id));
      } finally {
        setLoading(false);
      }
    },
    [clearError]
  );

  return {
    messages,
    sendMessage,
    loading,
    error,
    clearError,
  };
}
