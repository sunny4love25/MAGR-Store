import apiClient from './apiClient';

export async function fetchTags() {
  try {
    const response = await apiClient.get('/tags');
    if (!Array.isArray(response.data)) {
      throw new Error('Invalid tags data format received');
    }
    return response.data;
  } catch (error) {
    console.error('Failed to fetch tags:', error);
    throw new Error('Could not load tags at this time.');
  }
}
