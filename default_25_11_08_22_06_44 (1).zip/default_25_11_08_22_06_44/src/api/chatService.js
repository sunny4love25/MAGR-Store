import apiClient from './apiClient';

export async function sendMessageToAI(message, tags = []) {
  if (!message || typeof message !== 'string' || message.trim() === '') {
    throw new Error('Message cannot be empty');
  }
  try {
    const payload = {
      message: message.trim(),
      tags,
    };
    const response = await apiClient.post('/chat/message', payload);
    if (!response.data || typeof response.data.reply !== 'string') {
      throw new Error('Invalid AI response received');
    }
    return response.data.reply;
  } catch (error) {
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    }
    throw new Error('Failed to get response from AI. Please try again.');
  }
}

export async function fetchChatHistories() {
  try {
    const response = await apiClient.get('/chat/histories');
    if (!Array.isArray(response.data)) {
      throw new Error('Invalid chat histories format');
    }
    return response.data;
  } catch (error) {
    throw new Error('Could not load chat histories.');
  }
}

export async function fetchChatHistoryById(historyId) {
  if (!historyId) {
    throw new Error('Chat history ID is required');
  }
  try {
    const response = await apiClient.get(`/chat/histories/${historyId}`);
    if (!response.data || !Array.isArray(response.data.messages)) {
      throw new Error('Invalid chat history data');
    }
    return response.data;
  } catch (error) {
    throw new Error('Could not load chat history.');
  }
}

export async function deleteChatHistory(historyId) {
  if (!historyId) {
    throw new Error('Chat history ID is required');
  }
  try {
    await apiClient.delete(`/chat/histories/${historyId}`);
  } catch (error) {
    throw new Error('Failed to delete chat history.');
  }
}
