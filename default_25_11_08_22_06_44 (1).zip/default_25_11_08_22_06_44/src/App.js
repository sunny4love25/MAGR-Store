import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './components/Layout/Navbar';
import LoginForm from './components/Auth/LoginForm';
import RegisterForm from './components/Auth/RegisterForm';
import ChatInterface from './components/Chat/ChatInterface';
import ChatHistory from './components/Chat/ChatHistory';
import { useAuth } from './hooks/useAuth';

function App() {
  const { user } = useAuth();

  return (
    <div className="min-h-screen flex flex-col bg-background text-gray-900">
      <Navbar />
      <main className="flex-grow container mx-auto px-4 py-6 max-w-5xl w-full">
        <Routes>
          <Route
            path="/"
            element={user ? <ChatInterface /> : <Navigate to="/login" replace />}
          />
          <Route
            path="/history"
            element={user ? <ChatHistory /> : <Navigate to="/login" replace />}
          />
          <Route
            path="/login"
            element={!user ? <LoginForm /> : <Navigate to="/" replace />}
          />
          <Route
            path="/register"
            element={!user ? <RegisterForm /> : <Navigate to="/" replace />}
          />
          <Route
            path="*"
            element={<Navigate to={user ? "/" : "/login"} replace />}
          />
        </Routes>
      </main>
      <footer className="bg-gray-100 text-center py-4 text-sm text-gray-600">
        &copy; {new Date().getFullYear()} MAGR Solutions
      </footer>
    </div>
  );
}

export default App;
