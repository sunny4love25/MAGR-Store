# MAGR Solutions - AI Assistant Chat Web App

## Project Description

MAGR Solutions is a sophisticated web application providing AI assistant chat functionalities inspired by ChatGPT and Copilot. Users can register, login, and interact with an AI-powered assistant that understands context-enhancing tags fetched from the backend. The app supports persistent chat histories accessible anytime after login. The interface is designed to be beautiful, responsive, and user-friendly, leveraging modern React, Tailwind CSS, and best practices.

## Features

- User registration and authentication with secure JWT tokens.
- Real-time AI assistant chat interface supporting message sending and receiving.
- Contextual tags fetched from the API to enhance AI responses.
- Persistent chat history per user with ability to view and delete past conversations.
- Responsive and accessible UI with modern styling.
- Proper error handling and input validation.
- Token auto-expiration handling with automatic logout on invalid/expired tokens.

## Prerequisites

- Node.js (version 18 or newer recommended)
- npm (comes with Node.js)
- Modern web browser (Chrome, Firefox, Edge, Safari)

## Installation

1. Clone this repository:

   